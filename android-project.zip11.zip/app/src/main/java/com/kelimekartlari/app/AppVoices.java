package com.kelimekartlari.app;

import android.content.Context;
import android.media.AudioAttributes;
import android.media.AudioFormat;
import android.media.AudioTrack;

import com.k2fsa.sherpa.onnx.OfflineTts;

import org.apache.commons.compress.compressors.bzip2.BZip2CompressorInputStream;
import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FilterInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * The app's own natural voices (English, and one Turkish) (Piper voices, run on the device by sherpa-onnx).
 * A voice is downloaded once, only when the person asks for it, from the sherpa-onnx project's
 * official GitHub release over HTTPS, unpacked into the app's private storage, and then works
 * without internet. Nothing that is read aloud ever leaves the device.
 */
class AppVoices {

    interface Done { void done(String id); }

    /** id, name, gender, accent */
    static final String[][] VOICES = {
        {"en_US-amy-medium", "Amy", "f", "us"},
        {"en_US-kristin-medium", "Kristin", "f", "us"},
        {"en_US-joe-medium", "Joe", "m", "us"},
        {"en_US-bryce-medium", "Bryce", "m", "us"},
        {"en_GB-alba-medium", "Alba", "f", "gb"},
        {"en_GB-alan-medium", "Alan", "m", "gb"},
        // Turkish (male, from the DFKI Turkish speech recordings)
        {"tr_TR-dfki-medium", "Dfki", "m", "tr"},
        // Turkish (female, İlkız, MIT licence) and the same voice in a lower, warmer tone
        {"tr_TR-ilkiz-medium", "İlkız", "f", "tr"},
        {"tr_TR-ilkiz-warm", "İlkız · sıcak ton", "f", "tr"},
    };
    // İlkız comes as plain Piper files from Hugging Face; the app prepares them for sherpa-onnx on the tablet
    private static final String ILKIZ = "https://huggingface.co/ilkeraktuna/piper-tts-tr-ilkiz-medium/resolve/main/ilkiz.onnx";
    private static final String ESPEAK = "https://github.com/k2-fsa/sherpa-onnx/releases/download/tts-models/espeak-ng-data.tar.bz2";

    /** The folder a voice lives in (the warm tone shares İlkız's files). */
    static String base(String id) {
        return "tr_TR-ilkiz-warm".equals(id) ? "tr_TR-ilkiz-medium" : id;
    }

    /** Below 1 plays the voice lower (and the speed is raised to match, so the pace stays the same). */
    static float pitchOf(String id) {
        return "tr_TR-ilkiz-warm".equals(id) ? 0.9f : 1f;
    }

    private static boolean rawPiper(String id) {
        return "tr_TR-ilkiz-medium".equals(base(id));
    }
    private static final String SOURCE = "https://github.com/k2-fsa/sherpa-onnx/releases/download/tts-models/vits-piper-";
    static final String PREFIX = "app:";

    private final File root;
    private final Map<String, Integer> progress = new HashMap<>();
    private final Map<String, String> errors = new HashMap<>();
    private final ExecutorService speaker = Executors.newSingleThreadExecutor();
    // up to two loaded voices (an English and a Turkish one), so switching languages does not reload a model
    private final java.util.LinkedHashMap<String, OfflineTts> engines = new java.util.LinkedHashMap<>();
    private volatile AudioTrack track = null;
    private volatile int token = 0;
    private volatile float volume = 1f;

    /** 0..1, used by the sleep mode to read softly and fade out. */
    void setVolume(float v) {
        volume = Math.max(0f, Math.min(1f, v));
        AudioTrack t = track;
        if (t != null) try { t.setVolume(volume); } catch (Exception ignored) { }
    }

    AppVoices(Context ctx) {
        root = new File(ctx.getFilesDir(), "voices");
    }

    static boolean isAppVoice(String name) {
        return name != null && name.startsWith(PREFIX);
    }

    private static boolean known(String id) {
        for (String[] v : VOICES) if (v[0].equals(id)) return true;
        return false;
    }

    private File dir(String id) {
        return new File(root, id);
    }

    boolean installed(String id) {
        return known(id) && new File(dir(base(id)), ".ready").exists();
    }

    /** True when this "app:<id>" voice is downloaded and can speak. */
    boolean has(String voiceName) {
        return isAppVoice(voiceName) && installed(voiceName.substring(PREFIX.length()));
    }

    /** [{id, label, gender, accent, installed, progress (-1 when not downloading), error}] */
    synchronized String list() {
        JSONArray out = new JSONArray();
        try {
            for (String[] v : VOICES) {
                JSONObject o = new JSONObject();
                o.put("id", v[0]);
                o.put("label", v[1]);
                o.put("gender", v[2]);
                o.put("accent", v[3]);
                o.put("lang", "tr".equals(v[3]) ? "tr" : "en");
                o.put("installed", installed(v[0]));
                Integer p = progress.get(base(v[0]));
                o.put("progress", p == null ? -1 : p);
                String e = errors.get(base(v[0]));
                if (e != null) o.put("error", e);
                out.put(o);
            }
        } catch (Exception ignored) {
        }
        return out.toString();
    }

    /** Downloads and unpacks one voice in the background; list() shows the progress. */
    void download(final String voice) {
        if (!known(voice) || installed(voice)) return;
        final String id = base(voice);
        synchronized (this) {
            if (progress.containsKey(id)) return;
            progress.put(id, 0);
            errors.remove(id);
        }
        new Thread(() -> {
            File tmp = new File(root, id + ".part");
            try {
                deleteAll(tmp);
                if (!tmp.mkdirs()) throw new IOException("klasör");
                if (rawPiper(id)) downloadRaw(tmp, id);
                else {
                    HttpURLConnection c = open(SOURCE + id + ".tar.bz2");
                    long total = c.getContentLengthLong();
                    try (InputStream raw = c.getInputStream()) {
                        Counting counted = new Counting(new BufferedInputStream(raw, 1 << 16));
                        InputStream bz = new BZip2CompressorInputStream(counted);
                        untar(bz, tmp, id, counted, total);
                    } finally {
                        c.disconnect();
                    }
                }
                File model = findOnnx(tmp);
                if (model == null || !new File(model.getParentFile(), "tokens.txt").exists()) throw new IOException("eksik paket");
                File target = dir(id);
                deleteAll(target);
                if (!tmp.renameTo(target)) throw new IOException("kayıt");
                if (!new File(target, ".ready").createNewFile()) throw new IOException("kayıt");
                synchronized (this) { progress.remove(id); }
            } catch (Throwable e) {
                deleteAll(tmp);
                synchronized (this) {
                    progress.remove(id);
                    errors.put(id, "İndirilemedi. İnternet bağlantını kontrol edip tekrar dene.");
                }
            }
        }).start();
    }

    /** Removes a downloaded voice to free the space. */
    void delete(String voice) {
        if (!known(voice)) return;
        String id = base(voice);
        synchronized (engines) { engines.remove(id); }
        deleteAll(dir(id));
    }

    /**
     * A plain Piper voice: the shared espeak-ng data (once, from the sherpa-onnx release), the voice's
     * settings and model; then tokens.txt is written and the model gets the few labels sherpa-onnx reads.
     */
    private void downloadRaw(File tmp, String id) throws Exception {
        File esp = new File(root, "espeak-ng-data");
        if (!new File(esp, "phontab").exists()) {
            File et = new File(root, "espeak.part");
            deleteAll(et);
            if (!et.mkdirs()) throw new IOException("klasör");
            HttpURLConnection c = open(ESPEAK);
            long total = c.getContentLengthLong();
            try (InputStream raw = c.getInputStream()) {
                Counting counted = new Counting(new BufferedInputStream(raw, 1 << 16));
                untar(new BZip2CompressorInputStream(counted), et, id, counted, total);
            } finally {
                c.disconnect();
            }
            if (!new File(et, "phontab").exists()) { deleteAll(et); throw new IOException("eksik paket"); }
            deleteAll(esp);
            if (!et.renameTo(esp)) throw new IOException("kayıt");
        }
        // settings: the sound table becomes tokens.txt
        HttpURLConnection jc = open(ILKIZ + ".json");
        String json;
        try (InputStream in = jc.getInputStream()) {
            java.io.ByteArrayOutputStream b = new java.io.ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) > 0) { b.write(buf, 0, n); if (b.size() > (1 << 20)) throw new IOException("ayar"); }
            json = new String(b.toByteArray(), StandardCharsets.UTF_8);
        } finally {
            jc.disconnect();
        }
        JSONObject cfg = new JSONObject(json);
        writeTokens(cfg.getJSONObject("phoneme_id_map"), new File(tmp, "tokens.txt"));
        // the model itself
        File model = new File(tmp, "model.onnx");
        HttpURLConnection c = open(ILKIZ);
        long total = c.getContentLengthLong();
        try (InputStream raw = c.getInputStream(); OutputStream o = new FileOutputStream(model)) {
            byte[] buf = new byte[1 << 16];
            long done = 0;
            int n;
            while ((n = raw.read(buf)) > 0) {
                o.write(buf, 0, n);
                done += n;
                if (total > 0) { int p = (int) Math.min(99, done * 100 / total); synchronized (this) { progress.put(id, p); } }
            }
            if (total > 0 && done != total) throw new IOException("kesik");
        } finally {
            c.disconnect();
        }
        JSONObject lang = cfg.optJSONObject("language"), esk = cfg.optJSONObject("espeak"), audio = cfg.optJSONObject("audio");
        appendMeta(model, new String[][] {
            { "model_type", "vits" },
            { "comment", "piper" },
            { "language", lang != null ? lang.optString("name_english", "Turkish") : "Turkish" },
            { "voice", esk != null ? esk.optString("voice", "tr") : "tr" },
            { "has_espeak", "1" },
            { "n_speakers", String.valueOf(cfg.optInt("num_speakers", 1)) },
            { "sample_rate", String.valueOf(audio != null ? audio.optInt("sample_rate", 22050) : 22050) },
        });
    }

    /** One line per sound: "symbol id" (the first id of each), as sherpa-onnx's own converter writes it. */
    static void writeTokens(JSONObject map, File out) throws Exception {
        StringBuilder sb = new StringBuilder();
        java.util.Iterator<String> keys = map.keys();
        while (keys.hasNext()) {
            String k = keys.next();
            sb.append(k).append(' ').append(map.getJSONArray(k).getInt(0)).append('\n');
        }
        try (OutputStream o = new FileOutputStream(out)) { o.write(sb.toString().getBytes(StandardCharsets.UTF_8)); }
    }

    /** Adds labels to an ONNX model by appending metadata entries (protobuf field 14) to the end of the file. */
    static void appendMeta(File f, String[][] kv) throws IOException {
        java.io.ByteArrayOutputStream out = new java.io.ByteArrayOutputStream();
        for (String[] e : kv) {
            byte[] k = e[0].getBytes(StandardCharsets.UTF_8), v = e[1].getBytes(StandardCharsets.UTF_8);
            java.io.ByteArrayOutputStream entry = new java.io.ByteArrayOutputStream();
            entry.write(0x0A); varint(entry, k.length); entry.write(k, 0, k.length);
            entry.write(0x12); varint(entry, v.length); entry.write(v, 0, v.length);
            byte[] eb = entry.toByteArray();
            out.write(0x72); varint(out, eb.length); out.write(eb, 0, eb.length);
        }
        try (FileOutputStream o = new FileOutputStream(f, true)) { o.write(out.toByteArray()); }
    }

    private static void varint(java.io.ByteArrayOutputStream o, int v) {
        while ((v & ~0x7F) != 0) { o.write((v & 0x7F) | 0x80); v >>>= 7; }
        o.write(v);
    }

    /** Reads the text with an app voice ("app:<id>"); done is called when it has been read (not when stopped). */
    /** True when the last speak() could not make any sound (voice missing or the engine failed). */
    volatile boolean lastFailed = false;

    void speak(final String voiceName, final String text, final float speed, final String id, final Done done) {
        final String vid = voiceName.substring(PREFIX.length());
        final int my = ++token;
        stopTrack();
        speaker.execute(() -> {
            boolean finished = false;
            try {
                if (my != token) return;
                lastFailed = true;
                if (installed(vid) && text != null && text.trim().length() > 0) {
                    float pitch = pitchOf(vid);
                    OfflineTts t = engineFor(base(vid));
                    float[] s = PiperBridge.generate(t, text, speed / pitch);
                    int sr = PiperBridge.sampleRate(t);
                    if (my == token && s != null && s.length > 0) { lastFailed = false; play(s, Math.round(sr * pitch), my); }
                }
                finished = my == token;
            } catch (Throwable e) {
                lastFailed = true;
                finished = my == token;
            }
            if (finished && done != null) done.done(id);
        });
    }

    void stop() {
        token++;
        stopTrack();
    }

    private OfflineTts engineFor(String id) {
        synchronized (engines) {
            OfflineTts e = engines.remove(id);
            if (e != null) { engines.put(id, e); return e; }
        }
        File model = findOnnx(dir(id));
        if (model == null) throw new IllegalStateException("model");
        File base = model.getParentFile();
        File esp = new File(base, "espeak-ng-data");
        if (!esp.isDirectory()) esp = new File(root, "espeak-ng-data");
        OfflineTts e = PiperBridge.create(model.getAbsolutePath(), new File(base, "tokens.txt").getAbsolutePath(), esp.getAbsolutePath());
        synchronized (engines) {
            engines.put(id, e);
            while (engines.size() > 2) engines.remove(engines.keySet().iterator().next());
        }
        return e;
    }

    private void play(float[] s, int sr, int my) throws InterruptedException {
        int min = AudioTrack.getMinBufferSize(sr, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_FLOAT);
        if (min <= 0) min = 8192;
        AudioTrack t = new AudioTrack.Builder()
                .setAudioAttributes(new AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                        .build())
                .setAudioFormat(new AudioFormat.Builder()
                        .setEncoding(AudioFormat.ENCODING_PCM_FLOAT)
                        .setSampleRate(sr)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                        .build())
                .setBufferSizeInBytes(Math.max(min, 8192))
                .setTransferMode(AudioTrack.MODE_STREAM)
                .build();
        track = t;
        try { t.setVolume(volume); } catch (Exception ignored) { }
        try {
            t.play();
            int off = 0;
            while (off < s.length && my == token) {
                int n = Math.min(2048, s.length - off);
                int w = t.write(s, off, n, AudioTrack.WRITE_BLOCKING);
                if (w <= 0) break;
                off += w;
            }
            // let the last buffer play out before saying it has finished
            if (my == token) Thread.sleep((long) Math.max(min, 8192) / 4 * 1000L / sr + 150);
        } finally {
            try { t.stop(); } catch (Exception ignored) { }
            t.release();
            if (track == t) track = null;
        }
    }

    private void stopTrack() {
        AudioTrack t = track;
        if (t == null) return;
        try { t.pause(); t.flush(); } catch (Exception ignored) { }
    }

    /* ---------- download helpers ---------- */

    private static HttpURLConnection open(String url) throws IOException {
        for (int i = 0; i < 6; i++) {
            if (!url.startsWith("https://")) throw new IOException("güvensiz adres");
            HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
            c.setInstanceFollowRedirects(false);
            c.setConnectTimeout(20000);
            c.setReadTimeout(30000);
            c.setRequestProperty("User-Agent", "KelimeKartlari");
            int code = c.getResponseCode();
            if (code >= 300 && code < 400) {
                String loc = c.getHeaderField("Location");
                c.disconnect();
                if (loc == null) break;
                url = new URL(new URL(url), loc).toString();
                continue;
            }
            if (code != 200) {
                c.disconnect();
                throw new IOException("HTTP " + code);
            }
            return c;
        }
        throw new IOException("yönlendirme");
    }

    /** Unpacks a .tar stream into dest, dropping the archive's top folder; nothing may land outside dest. */
    private void untar(InputStream in, File dest, String id, Counting counted, long total) throws IOException {
        byte[] hdr = new byte[512];
        String base = dest.getCanonicalPath() + File.separator;
        String longName = null;
        while (readFully(in, hdr)) {
            boolean empty = true;
            for (byte b : hdr) if (b != 0) { empty = false; break; }
            if (empty) break;
            String name = longName != null ? longName : cstr(hdr, 0, 100);
            longName = null;
            boolean posix = hdr[257] == 'u' && hdr[258] == 's' && hdr[259] == 't' && hdr[260] == 'a' && hdr[261] == 'r' && hdr[262] == 0;
            if (posix) {
                String prefix = cstr(hdr, 345, 155);
                if (prefix.length() > 0) name = prefix + "/" + name;
            }
            long size = octal(hdr, 124, 12);
            byte type = hdr[156];
            if (type == 'L') {
                longName = new String(readBytes(in, size), StandardCharsets.UTF_8).replace("\0", "");
                skipPad(in, size);
                continue;
            }
            if (type == 'x') {
                String pax = new String(readBytes(in, size), StandardCharsets.UTF_8);
                skipPad(in, size);
                for (String line : pax.split("\n")) {
                    int sp = line.indexOf(' ');
                    if (sp > 0 && line.startsWith("path=", sp + 1)) longName = line.substring(sp + 6);
                }
                continue;
            }
            int slash = name.indexOf('/');
            String rel = slash >= 0 ? name.substring(slash + 1) : name;
            if (type == '5') {
                if (rel.length() > 0) { File d = new File(dest, rel); inside(d, base); d.mkdirs(); }
                skip(in, size);
            } else if ((type == '0' || type == 0) && rel.length() > 0 && !rel.endsWith("/")) {
                File f = new File(dest, rel);
                inside(f, base);
                File parent = f.getParentFile();
                if (parent != null) parent.mkdirs();
                try (OutputStream o = new FileOutputStream(f)) { copy(in, o, size); }
            } else {
                skip(in, size);
            }
            skipPad(in, size);
            if (total > 0) {
                int p = (int) Math.min(99, counted.count * 100 / total);
                synchronized (this) { progress.put(id, p); }
            }
        }
    }

    private static void inside(File f, String base) throws IOException {
        if (!f.getCanonicalPath().startsWith(base)) throw new IOException("güvensiz yol");
    }

    private static String cstr(byte[] b, int off, int len) {
        int end = off;
        while (end < off + len && b[end] != 0) end++;
        return new String(b, off, end - off, StandardCharsets.UTF_8).trim();
    }

    private static long octal(byte[] b, int off, int len) {
        long v = 0;
        for (int i = off; i < off + len; i++) {
            int c = b[i];
            if (c == 0 || c == ' ') { if (v > 0) break; else continue; }
            if (c < '0' || c > '7') break;
            v = v * 8 + (c - '0');
        }
        return v;
    }

    private static boolean readFully(InputStream in, byte[] buf) throws IOException {
        int off = 0;
        while (off < buf.length) {
            int n = in.read(buf, off, buf.length - off);
            if (n < 0) return false;
            off += n;
        }
        return true;
    }

    private static byte[] readBytes(InputStream in, long size) throws IOException {
        if (size > 1 << 20) throw new IOException("başlık");
        byte[] b = new byte[(int) size];
        if (!readFully(in, b)) throw new IOException("kesik");
        return b;
    }

    private static void copy(InputStream in, OutputStream out, long size) throws IOException {
        byte[] buf = new byte[1 << 16];
        long left = size;
        while (left > 0) {
            int n = in.read(buf, 0, (int) Math.min(buf.length, left));
            if (n < 0) throw new IOException("kesik");
            out.write(buf, 0, n);
            left -= n;
        }
    }

    private static void skip(InputStream in, long size) throws IOException {
        byte[] buf = new byte[8192];
        long left = size;
        while (left > 0) {
            int n = in.read(buf, 0, (int) Math.min(buf.length, left));
            if (n < 0) throw new IOException("kesik");
            left -= n;
        }
    }

    private static void skipPad(InputStream in, long size) throws IOException {
        long pad = (512 - (size % 512)) % 512;
        skip(in, pad);
    }

    private static File findOnnx(File d) {
        File[] files = d.listFiles();
        if (files == null) return null;
        for (File f : files) if (f.isFile() && f.getName().endsWith(".onnx")) return f;
        for (File f : files) if (f.isDirectory() && !f.getName().equals("espeak-ng-data")) { File r = findOnnx(f); if (r != null) return r; }
        return null;
    }

    private static void deleteAll(File f) {
        if (f == null || !f.exists()) return;
        File[] kids = f.listFiles();
        if (kids != null) for (File k : kids) deleteAll(k);
        //noinspection ResultOfMethodCallIgnored
        f.delete();
    }

    /** Counts the compressed bytes read, for the download percentage. */
    private static final class Counting extends FilterInputStream {
        volatile long count = 0;
        Counting(InputStream in) { super(in); }
        @Override public int read() throws IOException { int r = super.read(); if (r >= 0) count++; return r; }
        @Override public int read(byte[] b, int off, int len) throws IOException { int n = super.read(b, off, len); if (n > 0) count += n; return n; }
        @Override public long skip(long n) throws IOException { long s = super.skip(n); if (s > 0) count += s; return s; }
    }
}
