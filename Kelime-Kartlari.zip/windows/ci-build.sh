#!/usr/bin/env bash
# Builds the Windows installer of Kelime Kartları (run on GitHub by .github/workflows/windows.yml).
# 1) prepares the app folder, 2) checks that the voices download and speak (plain Node),
# 3) builds the installer, 4) checks the voices speak inside the finished app too.
set -euo pipefail

HERE="$(cd "$(dirname "$0")" && pwd)"   # src/windows
SRC="$(cd "$HERE/.." && pwd)"           # the unpacked Android project
OUT="${OUT:-$PWD/win}"
RUN="${RUN:-1}"
# paths as C:/like/this, which both bash and the Windows programs understand
winpath() { if command -v cygpath >/dev/null 2>&1; then cygpath -m "$1"; else printf '%s' "$1"; fi; }
mkdir -p "${RUNNER_TEMP:-$PWD/tmp}"
TESTDIR="$(winpath "${RUNNER_TEMP:-$PWD/tmp}")/kk-ses-deneme"

rm -rf "$OUT"
mkdir -p "$OUT/web"
cp -r "$SRC/app/src/main/assets/." "$OUT/web/"
cp "$HERE"/app/*.js "$OUT/"
# card drawings: the "gorsel-paket" zips uploaded to the repository go inside the app (web/cards/<word>.webp)
mkdir -p "$OUT/web/cards"
for z in *[Gg]*rsel-paket*.zip; do
  [ -f "$z" ] || continue
  unzip -q -o -j "$z" '*.webp' -d "$OUT/web/cards"
done
# packs added to the GitHub release "gorseller"
REL="https://github.com/${GITHUB_REPOSITORY:-alidinler43-debug/Ingilizce-Kelime-Kartlari}/releases/download/gorseller"
miss=0
for n in $(seq -w 1 30); do
  [ "$miss" -ge 3 ] && break
  f="Kelime-Kartlari-gorsel-paket-$n.zip"
  if curl -fsSL "$REL/$f" -o "/tmp/$f" 2>/dev/null; then unzip -q -o -j "/tmp/$f" '*.webp' -d "$OUT/web/cards"; miss=0; else miss=$((miss+1)); fi
done
echo "Kart çizimleri: $(ls "$OUT/web/cards" | wc -l)"
if [ -n "${ICON:-}" ] && [ -f "$ICON" ]; then cp "$ICON" "$OUT/icon.png"; fi

cd "$OUT"
node -e "
  const fs = require('fs');
  const hasIcon = fs.existsSync('icon.png');
  const pkg = {
    name: 'kelime-kartlari', productName: 'Kelime Kartları', version: '1.0.' + process.argv[1],
    description: 'Kelime Kartları', author: 'Kelime Kartları', main: 'main.js',
    dependencies: { 'sherpa-onnx-node': '1.12.10', 'sherpa-onnx-win-x64': '1.12.10', 'unbzip2-stream': '1.4.3' },
    devDependencies: { 'electron': '33.2.1', 'electron-builder': '25.1.8' },
    build: {
      appId: 'com.kelimekartlari.desktop', productName: 'Kelime Kartları', executableName: 'KelimeKartlari',
      artifactName: 'KelimeKartlari-Kurulum.\${ext}', directories: { output: 'dist' },
      asar: false, npmRebuild: false,
      files: ['*.js', 'web/**/*'].concat(hasIcon ? ['icon.png'] : []),
      win: Object.assign({ target: [{ target: 'nsis', arch: ['x64'] }] }, hasIcon ? { icon: 'icon.png' } : {}),
      nsis: { oneClick: true, perMachine: false, runAfterFinish: true, createDesktopShortcut: 'always',
              createStartMenuShortcut: true, shortcutName: 'Kelime Kartları', deleteAppDataOnUninstall: false,
              installerLanguages: ['tr_TR'], language: '1055' }
    }
  };
  fs.writeFileSync('package.json', JSON.stringify(pkg, null, 2));
" "$RUN"
cat package.json

echo "::group::Paketler"
npm install --no-audit --no-fund
ls node_modules/sherpa-onnx-win-x64
echo "::endgroup::"

echo "::group::Ses denemesi (Node)"
rm -rf "$TESTDIR"
MSYS_NO_PATHCONV=1 node "$(winpath "$HERE")/selftest-node.js" "$(winpath "$OUT")" "$TESTDIR"
echo "::endgroup::"

echo "::group::Kurulum dosyası"
npx electron-builder --win --publish never
ls -la dist
test -f dist/KelimeKartlari-Kurulum.exe
test -f dist/win-unpacked/resources/app/node_modules/sherpa-onnx-win-x64/sherpa-onnx.node || {
  echo "::error::Ses motoru kurulum dosyasına girmedi"; ls -R dist/win-unpacked/resources | head -80; exit 1; }
echo "::endgroup::"

echo "::group::Ses denemesi (bitmiş uygulamanın içinde)"
rm -f "$TESTDIR/selftest.json"
MSYS_NO_PATHCONV=1 timeout 300 ./dist/win-unpacked/KelimeKartlari.exe --kk-selftest="$TESTDIR" || echo "uygulama kodu: $?"
if [ ! -f "$TESTDIR/selftest.json" ]; then echo "::error::Uygulama içi ses denemesi sonuç vermedi"; exit 1; fi
cat "$TESTDIR/selftest.json"
node -e "process.exit(JSON.parse(require('fs').readFileSync(process.argv[1], 'utf8')).ok ? 0 : 1)" "$TESTDIR/selftest.json" || {
  echo "::error::Uygulama içinde sesler çalışmadı"; exit 1; }
echo "::endgroup::"
echo "Hazır: $OUT/dist/KelimeKartlari-Kurulum.exe"
