// Kelime Kartları for Windows: the same app as on the tablet, in its own window,
// with the app's own natural voices (downloaded once inside the app, then offline).
'use strict';
const { app, BrowserWindow, Menu, shell, ipcMain, utilityProcess, powerSaveBlocker } = require('electron');
const path = require('path');
const fs = require('fs');
const { VoiceStore } = require('./voices');

app.setAppUserModelId('com.kelimekartlari.desktop');

// --kk-selftest=<folder>: used only while building, to check the voices really speak in the finished app
const selftestArg = process.argv.filter(function (a) { return a.indexOf('--kk-selftest=') === 0; })[0];
const SELFTEST = selftestArg ? selftestArg.slice('--kk-selftest='.length).replace(/^"|"$/g, '') : '';
if (SELFTEST) app.disableHardwareAcceleration();

/** The voices folder. The voice engine needs a path with plain letters, so “Kelime Kartları” is not used in it. */
function voiceRoot() {
  if (SELFTEST) return SELFTEST;
  const own = path.join(app.getPath('appData'), 'KelimeKartlari', 'voices');
  if (/^[\x20-\x7e]*$/.test(own)) return own;
  return path.join(process.env.PUBLIC || 'C:\\Users\\Public', 'KelimeKartlari', 'voices');
}

let store = null;
function voices() {
  if (!store) {
    store = new VoiceStore(voiceRoot(), function (file, env) {
      return utilityProcess.fork(file, [], { serviceName: 'Kelime Kartları ses indirme', env: Object.assign({}, process.env, env) });
    });
  }
  return store;
}

/* ---------- the voice engine (its own process) ---------- */
let engine = null;
let seq = 0;
const waiting = new Map();
function engineProcess() {
  if (engine) return engine;
  const child = utilityProcess.fork(path.join(__dirname, 'tts-worker.js'), [], { serviceName: 'Kelime Kartları ses motoru' });
  child.on('message', function (m) {
    const w = m && waiting.get(m.seq);
    if (w && w.child === child) { waiting.delete(m.seq); w.done(m); }
  });
  child.on('exit', function () {
    if (engine === child) engine = null;
    // only the texts this engine was reading fail; a new engine may already be at work
    waiting.forEach(function (w, n) { if (w.child === child) { waiting.delete(n); w.done({ error: 'ses motoru kapandı' }); } });
  });
  engine = child;
  return child;
}
function stopEngine() {
  const e = engine;
  engine = null;
  if (e) { try { e.kill(); } catch (x) { /* already closed */ } }
}

/** Reads a text with an app voice: {samples, sampleRate, pitch} or {error}. */
function synthesize(id, text, speed) {
  return new Promise(function (resolve) {
    const s = voices();
    text = String(text || '').slice(0, 5000);
    if (!s.installed(id) || !text.trim()) { resolve({ error: 'ses yok' }); return; }
    const pitch = s.pitchOf(id);
    const n = ++seq;
    const timer = setTimeout(function () { if (waiting.delete(n)) resolve({ error: 'zaman aşımı' }); }, 60000);
    try {
      const child = engineProcess();
      waiting.set(n, { child: child, done: function (m) {
        clearTimeout(timer);
        if (m.error) resolve({ error: m.error });
        else resolve({ samples: m.samples, sampleRate: m.sampleRate, pitch: pitch });
      } });
      child.postMessage({ seq: n, dir: s.dir(id), espeak: s.espeakDir(), text: text, speed: Math.max(0.3, Math.min(3, Number(speed) || 1)) / pitch });
    } catch (e) {
      waiting.delete(n);
      clearTimeout(timer);
      resolve({ error: String((e && e.message) || e) });
    }
  });
}

/* ---------- what the page may ask for ---------- */
function fromApp(e) {
  try { return /^file:/i.test(e.senderFrame.url); } catch (x) { return false; }
}
ipcMain.on('kk-voices-list', function (e) { e.returnValue = fromApp(e) ? JSON.stringify(voices().list()) : '[]'; });
ipcMain.on('kk-voice-download', function (e, id) { if (fromApp(e)) voices().download(String(id || '')); });
ipcMain.on('kk-voice-delete', function (e, id) {
  if (!fromApp(e)) return;
  stopEngine();   // lets go of the voice's files before they are deleted
  voices().remove(String(id || ''));
});
ipcMain.handle('kk-tts', function (e, a) {
  if (!fromApp(e) || !a) return { error: 'izin yok' };
  return synthesize(String(a.id || ''), a.text, a.speed);
});
let awake = -1;
ipcMain.on('kk-awake', function (e, on) {
  if (on && awake < 0) awake = powerSaveBlocker.start('prevent-display-sleep');
  else if (!on && awake >= 0) { powerSaveBlocker.stop(awake); awake = -1; }
});

function webPrefs() {
  return {
    contextIsolation: true, sandbox: true, spellcheck: false,
    preload: path.join(__dirname, 'preload.js'),
    autoplayPolicy: 'no-user-gesture-required',
  };
}

function openWindow() {
  const icon = path.join(__dirname, 'icon.png');
  const win = new BrowserWindow({
    width: 1200, height: 820, minWidth: 380, minHeight: 560,
    backgroundColor: '#DDE4EB', title: 'Kelime Kartları', autoHideMenuBar: true,
    icon: fs.existsSync(icon) ? icon : undefined,
    webPreferences: webPrefs(),
  });
  Menu.setApplicationMenu(null);
  // links to other sites open in the normal web browser; the app itself stays in its window
  win.webContents.setWindowOpenHandler(function (d) {
    if (/^https?:/i.test(d.url)) shell.openExternal(d.url);
    return { action: 'deny' };
  });
  win.webContents.on('will-navigate', function (e, url) {
    if (/^https?:/i.test(url)) { e.preventDefault(); shell.openExternal(url); }
  });
  win.loadFile(path.join(__dirname, 'web', 'index.html'));
}

/* ---------- the build-time check ---------- */
async function selftest() {
  const out = { ok: false, steps: [] };
  try {
    const s = voices();
    const ids = s.list().filter(function (v) { return v.installed; }).map(function (v) { return v.id; });
    if (!ids.length) throw new Error('hiç ses yok');
    for (const id of ids) {
      const r = await synthesize(id, /^tr/.test(id) ? 'Merhaba, bu bir denemedir.' : 'Hello, this is a test.', 1);
      if (r.error) throw new Error(id + ': ' + r.error);
      if (!(r.samples && r.samples.length > r.sampleRate * 0.3)) throw new Error(id + ': ses çok kısa');
      out.steps.push(id + ': ' + r.samples.length + ' örnek, ' + r.sampleRate + ' Hz, ton ' + r.pitch);
    }
    // the page sees the bridge and the voice list
    const win = new BrowserWindow({ show: false, webPreferences: webPrefs() });
    await win.loadFile(path.join(__dirname, 'web', 'index.html'));
    const seen = JSON.parse(await win.webContents.executeJavaScript(
      '(function(){ try { var a = window.AndroidTTS; return JSON.stringify({ t: typeof a, sp: typeof a.speakLang, n: JSON.parse(a.appVoices()).length }); } catch (e) { return JSON.stringify({ err: String(e) }); } })()'));
    out.steps.push('sayfa: ' + JSON.stringify(seen));
    if (seen.t !== 'object' || seen.sp !== 'function' || !(seen.n >= 9)) throw new Error('sayfa ses köprüsünü görmüyor');
    // reading aloud through the page (only noted: the build machine has no speakers)
    const en = ids.filter(function (i) { return /^en/.test(i); })[0] || ids[0];
    const said = await win.webContents.executeJavaScript(
      'new Promise(function(r){ var t = setTimeout(function(){ r("süre doldu"); }, 20000);' +
      ' window.__ttsDone = function(id){ clearTimeout(t); r("bitti " + id); };' +
      ' window.AndroidTTS.setVoice(' + JSON.stringify('app:' + en) + '); window.AndroidTTS.speakLang("Hello there.", "en", "st1"); })');
    out.steps.push('sayfadan okuma: ' + said);
    out.ok = true;
  } catch (e) {
    out.error = String((e && e.message) || e);
  }
  try { fs.writeFileSync(path.join(SELFTEST, 'selftest.json'), JSON.stringify(out, null, 2)); } catch (e) { /* the build sees no file */ }
  stopEngine();
  app.exit(out.ok ? 0 : 1);
}

if (SELFTEST) {
  app.whenReady().then(selftest);
} else if (!app.requestSingleInstanceLock()) {
  app.quit();
} else {
  app.on('second-instance', function () {
    const w = BrowserWindow.getAllWindows()[0];
    if (w) { if (w.isMinimized()) w.restore(); w.focus(); }
  });
  app.whenReady().then(openWindow);
  app.on('window-all-closed', function () { app.quit(); });
  app.on('will-quit', stopEngine);
}
