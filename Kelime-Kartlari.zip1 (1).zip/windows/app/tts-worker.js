// The voice engine runs in its own small process, so reading aloud never freezes the app window.
'use strict';
const { createEngine, synth } = require('./tts-engine');

let sherpa = null;
let loadError = '';
try { sherpa = require('sherpa-onnx-node'); } catch (e) { loadError = String((e && e.message) || e); }

// up to two loaded voices (an English and a Turkish one), so switching languages does not reload a model
const engines = new Map();

function send(m) {
  if (process.parentPort) process.parentPort.postMessage(m);
  else if (process.send) process.send(m);
}

function handle(m) {
  if (!m || typeof m !== 'object') return;
  try {
    if (!sherpa) throw new Error('ses motoru açılamadı: ' + loadError);
    let t = engines.get(m.dir);
    if (t) engines.delete(m.dir);
    else t = createEngine(sherpa, m.dir, m.espeak);
    engines.set(m.dir, t);
    while (engines.size > 2) engines.delete(engines.keys().next().value);
    const a = synth(t, m.text, m.speed);
    send({ seq: m.seq, samples: a.samples, sampleRate: a.sampleRate });
  } catch (e) {
    send({ seq: m.seq, error: String((e && e.message) || e) });
  }
}

if (process.parentPort) process.parentPort.on('message', function (e) { handle(e.data); });
else process.on('message', handle);
