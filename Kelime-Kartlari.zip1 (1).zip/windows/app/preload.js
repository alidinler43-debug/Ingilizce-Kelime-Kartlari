// Kelime Kartları for Windows: gives the page the same speech bridge it has on the tablet
// (window.AndroidTTS), so the app's own natural voices, the voice lists and the listening mode work
// here too. Windows' own voices are read with the browser's speech; the app's voices come from the
// app's voice engine. The tablet-only parts (background service, notifications, battery) are left out,
// so the page uses its in-window versions of them.
'use strict';
const { contextBridge, ipcRenderer, webFrame } = require('electron');

let wantedVoice = '';
let wantedTrVoice = '';
let rate = 0.9;
let pitch = 1;
let token = 0;
let audioCtx = null;
let current = null;
const synth = window.speechSynthesis;
try { synth.getVoices(); } catch (e) { /* no speech on this PC */ }

function isApp(name) { return typeof name === 'string' && name.indexOf('app:') === 0; }
/** The tablet's rule: the app voices read at the chosen rate, 0.9 being their normal pace. */
function appSpeed() { return Math.max(0.5, Math.min(2, rate / 0.9)); }
function allVoices() { try { return synth.getVoices() || []; } catch (e) { return []; } }
function langOf(v) { return String((v && v.lang) || '').toLowerCase().replace('_', '-'); }
function sysList(lang) {
  return allVoices().filter(function (v) { return langOf(v).indexOf(lang) === 0; })
    .map(function (v) { return { name: v.name, locale: v.lang, network: !v.localService, missing: false }; });
}
function appList() {
  try { return JSON.parse(ipcRenderer.sendSync('kk-voices-list') || '[]'); } catch (e) { return []; }
}
function appReady(name) {
  if (!isApp(name)) return false;
  const id = name.slice(4);
  return appList().some(function (v) { return v.id === id && v.installed; });
}
/** Tells the page that a text with this id has been read (as the tablet does). */
function done(id) {
  if (id === null || id === undefined) return;
  webFrame.executeJavaScript('window.__ttsDone && window.__ttsDone(' + JSON.stringify(String(id)) + ')').catch(function () {});
}
function stopAll() {
  token++;
  try { synth.cancel(); } catch (e) { /* nothing playing */ }
  const c = current;
  current = null;
  if (c) { try { c.onended = null; c.stop(); } catch (e) { /* already stopped */ } }
}

/** Reads with one of Windows' own voices. */
function sysSpeak(text, lang, voiceName, id, my) {
  try {
    const tr = lang === 'tr';
    const u = new SpeechSynthesisUtterance(text);
    u.lang = tr ? 'tr-TR' : 'en-US';
    u.rate = rate;
    u.pitch = tr ? 1 : pitch;
    const all = allVoices();
    let v = voiceName && !isApp(voiceName) ? all.filter(function (x) { return x.name === voiceName; })[0] : null;
    if (!v) v = all.filter(function (x) { return langOf(x).indexOf(tr ? 'tr' : 'en-us') === 0; })[0] || all.filter(function (x) { return langOf(x).indexOf(tr ? 'tr' : 'en') === 0; })[0];
    if (v) u.voice = v;
    const fin = function () { if (my === token) done(id); };
    u.onend = fin;
    u.onerror = fin;
    synth.speak(u);
  } catch (e) {
    if (my === token) done(id);
  }
}

/** Reads with one of the app's own voices; if that cannot make a sound, Windows' voice reads it. */
async function appSpeak(name, text, lang, id, my) {
  let r = null;
  try { r = await ipcRenderer.invoke('kk-tts', { id: name.slice(4), text: text, speed: appSpeed() }); } catch (e) { r = null; }
  if (my !== token) return;
  if (!r || r.error || !r.samples || !r.samples.length) { sysSpeak(text, lang, '', id, my); return; }
  try {
    if (!audioCtx) audioCtx = new AudioContext();
    if (audioCtx.state === 'suspended') await audioCtx.resume();
    if (my !== token) return;
    const samples = r.samples instanceof Float32Array ? r.samples : new Float32Array(r.samples);
    // a lower tone plays the sound a little slower (the engine already read it faster to match)
    const sr = Math.max(3000, Math.round(r.sampleRate * (r.pitch || 1)));
    const buf = audioCtx.createBuffer(1, samples.length, sr);
    buf.copyToChannel(samples, 0);
    const src = audioCtx.createBufferSource();
    src.buffer = buf;
    src.connect(audioCtx.destination);
    src.onended = function () { if (current === src) current = null; if (my === token) done(id); };
    current = src;
    src.start();
  } catch (e) {
    if (my === token) sysSpeak(text, lang, '', id, my);
  }
}

contextBridge.exposeInMainWorld('AndroidTTS', {
  speak: function (text) {
    stopAll();
    const my = token;
    const t = String(text || '');
    if (appReady(wantedVoice)) appSpeak(wantedVoice, t, 'en', null, my);
    else sysSpeak(t, 'en', wantedVoice, null, my);
  },
  /** Reads a text in English ("en") or Turkish ("tr"); the page is told with the id when it ends. */
  speakLang: function (text, lang, id) {
    stopAll();
    const my = token;
    const tr = /^tr/i.test(String(lang || ''));
    const v = tr ? wantedTrVoice : wantedVoice;
    const t = String(text || '');
    if (appReady(v)) appSpeak(v, t, tr ? 'tr' : 'en', id, my);
    else sysSpeak(t, tr ? 'tr' : 'en', v, id, my);
  },
  hasLang: function (lang) {
    const l = String(lang || '').toLowerCase();
    if (sysList(l).length) return true;
    return appList().some(function (v) { return v.lang === l && v.installed; });
  },
  stop: function () { stopAll(); },
  keepAwake: function (on) { ipcRenderer.send('kk-awake', !!on); },
  appVoices: function () { try { return ipcRenderer.sendSync('kk-voices-list') || '[]'; } catch (e) { return '[]'; } },
  appVoiceDownload: function (id) { ipcRenderer.send('kk-voice-download', String(id || '')); },
  appVoiceDelete: function (id) { ipcRenderer.send('kk-voice-delete', String(id || '')); },
  voices: function () { return JSON.stringify(sysList('en')); },
  voicesTr: function () { return JSON.stringify(sysList('tr')); },
  setVoice: function (name) { wantedVoice = name == null ? '' : String(name); },
  setTrVoice: function (name) { wantedTrVoice = name == null ? '' : String(name); },
  setRate: function (r) { const n = Number(r); if (n > 0) rate = n; },
  setPitch: function (p) { const n = Number(p); if (n > 0) pitch = n; },
  ready: function () { return true; },
});
