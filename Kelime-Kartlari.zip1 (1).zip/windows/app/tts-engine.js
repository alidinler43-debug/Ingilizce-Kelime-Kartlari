// Turns text into sound with a downloaded voice (sherpa-onnx, the same open-source engine as on the tablet).
'use strict';
const fs = require('fs');
const path = require('path');

function findOnnx(d) {
  let names;
  try { names = fs.readdirSync(d, { withFileTypes: true }); } catch (e) { return null; }
  for (const n of names) if (n.isFile() && /\.onnx$/i.test(n.name)) return path.join(d, n.name);
  for (const n of names) {
    if (n.isDirectory() && n.name !== 'espeak-ng-data') { const r = findOnnx(path.join(d, n.name)); if (r) return r; }
  }
  return null;
}

/** Loads a voice: its model, tokens.txt and the espeak-ng data (its own, or the shared one). */
function createEngine(sherpa, dir, espeakRoot) {
  const model = findOnnx(dir);
  if (!model) throw new Error('model yok');
  const base = path.dirname(model);
  let esp = path.join(base, 'espeak-ng-data');
  if (!fs.existsSync(esp)) esp = espeakRoot;
  return new sherpa.OfflineTts({
    model: {
      vits: { model: model, tokens: path.join(base, 'tokens.txt'), dataDir: esp },
      debug: false,
      numThreads: 2,
      provider: 'cpu',
    },
    maxNumSentences: 1,
  });
}

/** {samples: Float32Array, sampleRate}; the samples are copied into ordinary memory (Electron needs that). */
function synth(tts, text, speed) {
  const a = tts.generate({ text: String(text), sid: 0, speed: speed > 0 ? speed : 1, enableExternalBuffer: false });
  return { samples: a.samples, sampleRate: a.sampleRate };
}

module.exports = { findOnnx, createEngine, synth };
