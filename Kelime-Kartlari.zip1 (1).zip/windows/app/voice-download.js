// Downloads and prepares ONE voice, then exits. It runs as its own small process, so a slow
// download or unpacking never holds up the app window. Only https addresses of the two official
// sources are used (the sherpa-onnx project's GitHub release, and İlkız's Hugging Face page).
'use strict';
const fs = require('fs');
const path = require('path');
const https = require('https');

const SOURCE = 'https://github.com/k2-fsa/sherpa-onnx/releases/download/tts-models/vits-piper-';
// İlkız comes as plain Piper files from Hugging Face; they are prepared for sherpa-onnx here
const ILKIZ = 'https://huggingface.co/ilkeraktuna/piper-tts-tr-ilkiz-medium/resolve/main/ilkiz.onnx';
const ESPEAK = 'https://github.com/k2-fsa/sherpa-onnx/releases/download/tts-models/espeak-ng-data.tar.bz2';

function send(m) {
  try {
    if (process.parentPort) process.parentPort.postMessage(m);
    else if (process.send) process.send(m);
  } catch (e) { /* the app has gone away */ }
}
let lastProgress = -1;
function progress(p) {
  p = Math.max(0, Math.min(99, Math.floor(p)));
  if (p !== lastProgress) { lastProgress = p; send({ progress: p }); }
}

function rmrf(p) { try { fs.rmSync(p, { recursive: true, force: true }); } catch (e) { /* ignore */ } }
function sleep(ms) { return new Promise(function (r) { setTimeout(r, ms); }); }

/** Opens an https address (following up to 6 redirects, all of them https too). */
function get(url, hops) {
  hops = hops || 0;
  return new Promise(function (resolve, reject) {
    if (!/^https:\/\//i.test(url)) { reject(new Error('güvensiz adres')); return; }
    const req = https.get(url, { headers: { 'User-Agent': 'KelimeKartlari' }, timeout: 30000 }, function (res) {
      const code = res.statusCode || 0;
      if (code >= 300 && code < 400 && res.headers.location) {
        res.resume();
        if (hops >= 6) { reject(new Error('yönlendirme')); return; }
        let next;
        try { next = new URL(res.headers.location, url).toString(); } catch (e) { reject(new Error('yönlendirme')); return; }
        get(next, hops + 1).then(resolve, reject);
        return;
      }
      if (code !== 200) { res.resume(); reject(new Error('HTTP ' + code)); return; }
      resolve(res);
    });
    req.on('timeout', function () { req.destroy(new Error('zaman aşımı')); });
    req.on('error', reject);
  });
}

/** Downloads a whole file; onBytes(done, total) reports how far it is. */
async function fetchFile(url, file, onBytes) {
  const res = await get(url);
  const total = Number(res.headers['content-length']) || 0;
  let done = 0;
  await new Promise(function (resolve, reject) {
    const out = fs.createWriteStream(file);
    let ended = false;
    res.on('data', function (c) { done += c.length; if (onBytes) onBytes(done, total); });
    res.on('end', function () { ended = true; });
    res.on('aborted', function () { reject(new Error('kesik')); });
    res.on('error', reject);
    out.on('error', reject);
    out.on('finish', function () {
      if (!ended || (total > 0 && done !== total)) reject(new Error('kesik'));
      else resolve();
    });
    res.pipe(out);
  });
}

/** Reads a small text file (settings), at most max bytes. */
async function fetchText(url, max) {
  const res = await get(url);
  return new Promise(function (resolve, reject) {
    const parts = [];
    let n = 0;
    res.on('data', function (c) {
      n += c.length;
      if (n > max) { res.destroy(new Error('ayar')); return; }
      parts.push(c);
    });
    res.on('end', function () { resolve(Buffer.concat(parts).toString('utf8')); });
    res.on('error', reject);
  });
}

/** Downloads a .tar.bz2 and unpacks it into dest, dropping the archive's top folder. */
async function fetchTarBz2(url, dest, onBytes) {
  const bunzip2 = require('unbzip2-stream');
  const tarFile = dest + '.tar';
  const res = await get(url);
  const total = Number(res.headers['content-length']) || 0;
  let done = 0;
  try {
    await new Promise(function (resolve, reject) {
      const dec = bunzip2();
      const out = fs.createWriteStream(tarFile);
      let ended = false;
      res.on('data', function (c) { done += c.length; if (onBytes) onBytes(done, total); });
      res.on('end', function () { ended = true; });
      res.on('aborted', function () { reject(new Error('kesik')); });
      res.on('error', reject);
      dec.on('error', reject);
      out.on('error', reject);
      out.on('finish', function () {
        if (!ended || (total > 0 && done !== total)) reject(new Error('kesik'));
        else resolve();
      });
      res.pipe(dec).pipe(out);
    });
    untarFile(tarFile, dest);
  } finally {
    rmrf(tarFile);
  }
}

function cstr(b, off, len) {
  let end = off;
  while (end < off + len && b[end] !== 0) end++;
  return b.toString('utf8', off, end).trim();
}
function octal(b, off, len) {
  let v = 0;
  for (let i = off; i < off + len; i++) {
    const c = b[i];
    if (c === 0 || c === 32) { if (v > 0) break; else continue; }
    if (c < 48 || c > 55) break;
    v = v * 8 + (c - 48);
  }
  return v;
}

/** Unpacks a .tar file into dest, dropping its top folder; nothing may land outside dest. */
function untarFile(tarFile, dest) {
  const fd = fs.openSync(tarFile, 'r');
  const size = fs.fstatSync(fd).size;
  const root = path.resolve(dest);
  const inside = function (p) {
    const r = path.resolve(root, p);
    if (r !== root && r.indexOf(root + path.sep) !== 0) throw new Error('güvensiz yol');
    return r;
  };
  const hdr = Buffer.alloc(512);
  const buf = Buffer.alloc(1 << 20);
  let pos = 0;
  let longName = null;
  try {
    while (pos + 512 <= size) {
      fs.readSync(fd, hdr, 0, 512, pos);
      pos += 512;
      let empty = true;
      for (let i = 0; i < 512; i++) if (hdr[i] !== 0) { empty = false; break; }
      if (empty) break;
      let name = longName !== null ? longName : cstr(hdr, 0, 100);
      const fromLong = longName !== null;
      longName = null;
      const posix = hdr.toString('latin1', 257, 263) === 'ustar\u0000';
      if (posix && !fromLong) {
        const prefix = cstr(hdr, 345, 155);
        if (prefix.length > 0) name = prefix + '/' + name;
      }
      const len = octal(hdr, 124, 12);
      const pad = (512 - (len % 512)) % 512;
      const type = hdr[156];
      if (pos + len > size) throw new Error('kesik');
      if (type === 76 /* L */ || type === 120 /* x */) {
        if (len > (1 << 20)) throw new Error('başlık');
        const b = Buffer.alloc(len);
        fs.readSync(fd, b, 0, len, pos);
        if (type === 76) longName = b.toString('utf8').replace(/\u0000/g, '');
        else {
          b.toString('utf8').split('\n').forEach(function (line) {
            const sp = line.indexOf(' ');
            if (sp > 0 && line.indexOf('path=', sp + 1) === sp + 1) longName = line.substring(sp + 6);
          });
        }
        pos += len + pad;
        continue;
      }
      const slash = name.indexOf('/');
      const rel = slash >= 0 ? name.substring(slash + 1) : name;
      if (type === 53 /* 5: folder */) {
        if (rel.length > 0) fs.mkdirSync(inside(rel), { recursive: true });
      } else if ((type === 48 /* 0 */ || type === 0) && rel.length > 0 && !/\/$/.test(rel)) {
        const target = inside(rel);
        fs.mkdirSync(path.dirname(target), { recursive: true });
        const out = fs.openSync(target, 'w');
        try {
          let left = len;
          let at = pos;
          while (left > 0) {
            const n = fs.readSync(fd, buf, 0, Math.min(buf.length, left), at);
            if (n <= 0) throw new Error('kesik');
            fs.writeSync(out, buf, 0, n);
            left -= n;
            at += n;
          }
        } finally {
          fs.closeSync(out);
        }
      }
      pos += len + pad;
    }
  } finally {
    fs.closeSync(fd);
  }
}

/** One line per sound: "symbol id" (the first id of each), as sherpa-onnx's own converter writes it. */
function writeTokens(map, file) {
  let s = '';
  Object.keys(map).forEach(function (k) { s += k + ' ' + map[k][0] + '\n'; });
  fs.writeFileSync(file, s, 'utf8');
}

function varint(arr, v) {
  while ((v & ~0x7f) !== 0) { arr.push((v & 0x7f) | 0x80); v >>>= 7; }
  arr.push(v);
}
/** Adds labels to an ONNX model by appending metadata entries (protobuf field 14) to the end of the file. */
function appendMeta(file, kv) {
  const out = [];
  kv.forEach(function (e) {
    const k = Buffer.from(e[0], 'utf8');
    const v = Buffer.from(e[1], 'utf8');
    const entry = [];
    entry.push(0x0a); varint(entry, k.length); for (const x of k) entry.push(x);
    entry.push(0x12); varint(entry, v.length); for (const x of v) entry.push(x);
    out.push(0x72); varint(out, entry.length); for (const x of entry) out.push(x);
  });
  fs.appendFileSync(file, Buffer.from(out));
}

function findOnnx(d) {
  let names;
  try { names = fs.readdirSync(d, { withFileTypes: true }); } catch (e) { return null; }
  for (const n of names) if (n.isFile() && /\.onnx$/i.test(n.name)) return path.join(d, n.name);
  for (const n of names) {
    if (n.isDirectory() && n.name !== 'espeak-ng-data') { const r = findOnnx(path.join(d, n.name)); if (r) return r; }
  }
  return null;
}

/** Windows may keep a fresh file busy for a moment (virus scan): try the move a few times. */
async function moveDir(from, to) {
  for (let i = 0; ; i++) {
    try { fs.renameSync(from, to); return; } catch (e) {
      if (i >= 20) throw e;
      await sleep(300);
    }
  }
}

/** A voice from the sherpa-onnx release: one archive with the model, tokens.txt and espeak-ng-data. */
async function prepareRelease(id, tmp) {
  await fetchTarBz2(SOURCE + id + '.tar.bz2', tmp, function (d, t) { if (t) progress(95 * d / t); });
}

/** İlkız: the shared espeak-ng data (once), the settings and the model; then tokens.txt and the labels. */
async function prepareIlkiz(root, tmp) {
  const esp = path.join(root, 'espeak-ng-data');
  if (!fs.existsSync(path.join(esp, 'phontab'))) {
    const et = path.join(root, 'espeak.part');
    rmrf(et);
    fs.mkdirSync(et, { recursive: true });
    await fetchTarBz2(ESPEAK, et, function (d, t) { if (t) progress(10 * d / t); });
    if (!fs.existsSync(path.join(et, 'phontab'))) { rmrf(et); throw new Error('eksik paket'); }
    rmrf(esp);
    await moveDir(et, esp);
  }
  const cfg = JSON.parse(await fetchText(ILKIZ + '.json', 1 << 20));
  if (!cfg || typeof cfg.phoneme_id_map !== 'object') throw new Error('ayar');
  writeTokens(cfg.phoneme_id_map, path.join(tmp, 'tokens.txt'));
  const model = path.join(tmp, 'model.onnx');
  await fetchFile(ILKIZ, model, function (d, t) { if (t) progress(10 + 88 * d / t); });
  const lang = cfg.language || {};
  const esk = cfg.espeak || {};
  const audio = cfg.audio || {};
  appendMeta(model, [
    ['model_type', 'vits'],
    ['comment', 'piper'],
    ['language', String(lang.name_english || 'Turkish')],
    ['voice', String(esk.voice || 'tr')],
    ['has_espeak', '1'],
    ['n_speakers', String(cfg.num_speakers || 1)],
    ['sample_rate', String(audio.sample_rate || 22050)],
  ]);
}

async function prepare(root, id) {
  if (!/^[a-z]{2}_[A-Z]{2}-[a-z0-9]+-[a-z]+$/.test(id)) throw new Error('bilinmeyen ses');
  fs.mkdirSync(root, { recursive: true });
  const tmp = path.join(root, id + '.part');
  rmrf(tmp);
  fs.mkdirSync(tmp, { recursive: true });
  try {
    if (id === 'tr_TR-ilkiz-medium') await prepareIlkiz(root, tmp);
    else await prepareRelease(id, tmp);
    const model = findOnnx(tmp);
    if (!model || !fs.existsSync(path.join(path.dirname(model), 'tokens.txt'))) throw new Error('eksik paket');
    progress(99);
    const target = path.join(root, id);
    rmrf(target);
    await moveDir(tmp, target);
    fs.writeFileSync(path.join(target, '.ready'), '');
  } catch (e) {
    rmrf(tmp);
    throw e;
  }
}

module.exports = { get, fetchFile, fetchText, fetchTarBz2, untarFile, writeTokens, appendMeta, findOnnx, prepare, SOURCE, ILKIZ, ESPEAK };

// started by the app as a download job
if (process.env.KK_VOICE_JOB === '1') {
  prepare(process.env.KK_VOICE_ROOT || '', process.env.KK_VOICE_ID || '').then(function () {
    send({ done: true });
    setTimeout(function () { process.exit(0); }, 100);
  }, function (e) {
    send({ error: String((e && e.message) || e) });
    setTimeout(function () { process.exit(1); }, 100);
  });
}
