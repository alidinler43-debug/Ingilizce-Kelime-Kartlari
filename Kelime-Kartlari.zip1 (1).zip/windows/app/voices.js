// The app's own natural voices on Windows: the same list as on the tablet.
// A voice is downloaded once, only when asked for, from the same official sources over HTTPS,
// kept in the user's own folder, and then works without internet. Nothing read aloud leaves the PC.
'use strict';
const fs = require('fs');
const path = require('path');

/** id, name, gender, accent */
const VOICES = [
  ['en_US-amy-medium', 'Amy', 'f', 'us'],
  ['en_US-kristin-medium', 'Kristin', 'f', 'us'],
  ['en_US-joe-medium', 'Joe', 'm', 'us'],
  ['en_US-bryce-medium', 'Bryce', 'm', 'us'],
  ['en_GB-alba-medium', 'Alba', 'f', 'gb'],
  ['en_GB-alan-medium', 'Alan', 'm', 'gb'],
  // Turkish (male, from the DFKI Turkish speech recordings)
  ['tr_TR-dfki-medium', 'Dfki', 'm', 'tr'],
  // Turkish (female, İlkız, MIT licence) and the same voice in a lower, warmer tone
  ['tr_TR-ilkiz-medium', 'İlkız', 'f', 'tr'],
  ['tr_TR-ilkiz-warm', 'İlkız · sıcak ton', 'f', 'tr'],
];

const FAILED = 'İndirilemedi. İnternet bağlantını kontrol edip tekrar dene.';

/** The folder a voice lives in (the warm tone shares İlkız's files). */
function base(id) { return id === 'tr_TR-ilkiz-warm' ? 'tr_TR-ilkiz-medium' : id; }
/** Below 1 plays the voice lower (the speed is raised to match, so the pace stays the same). */
function pitchOf(id) { return id === 'tr_TR-ilkiz-warm' ? 0.9 : 1; }
function known(id) { return VOICES.some(function (v) { return v[0] === id; }); }
function rmrf(p) { try { fs.rmSync(p, { recursive: true, force: true }); } catch (e) { /* ignore */ } }

class VoiceStore {
  /**
   * root: the folder the voices are kept in.
   * fork(file, env): starts voice-download.js as its own small process; returns an object that
   * emits 'message' and 'exit' and has kill() (Electron's utilityProcess or Node's child_process).
   */
  constructor(root, fork) {
    this.root = root;
    this.fork = fork;
    this.progress = new Map();
    this.errors = new Map();
    this.jobs = new Map();
    try { fs.mkdirSync(root, { recursive: true }); } catch (e) { /* shown as a failed download later */ }
  }

  dir(id) { return path.join(this.root, base(id)); }
  espeakDir() { return path.join(this.root, 'espeak-ng-data'); }
  pitchOf(id) { return pitchOf(id); }
  known(id) { return known(id); }

  installed(id) { return known(id) && fs.existsSync(path.join(this.dir(id), '.ready')); }

  /** [{id, label, gender, accent, lang, installed, progress (-1 when not downloading), error}] */
  list() {
    return VOICES.map((v) => {
      const b = base(v[0]);
      const o = {
        id: v[0], label: v[1], gender: v[2], accent: v[3], lang: v[3] === 'tr' ? 'tr' : 'en',
        installed: this.installed(v[0]),
        progress: this.progress.has(b) ? this.progress.get(b) : -1,
      };
      if (this.errors.has(b)) o.error = this.errors.get(b);
      return o;
    });
  }

  /** Downloads and prepares one voice in the background; list() shows the progress. */
  download(id) {
    if (!known(id) || this.installed(id)) return;
    const b = base(id);
    if (this.jobs.has(b)) return;
    this.progress.set(b, 0);
    this.errors.delete(b);
    let child;
    try {
      child = this.fork(path.join(__dirname, 'voice-download.js'), { KK_VOICE_JOB: '1', KK_VOICE_ROOT: this.root, KK_VOICE_ID: b });
    } catch (e) {
      this.progress.delete(b);
      this.errors.set(b, FAILED);
      return;
    }
    this.jobs.set(b, child);
    let reason = '';
    child.on('message', (m) => {
      if (!m || typeof m !== 'object') return;
      if (typeof m.progress === 'number' && this.jobs.get(b) === child) this.progress.set(b, Math.max(0, Math.min(99, Math.round(m.progress))));
      if (m.error) reason = String(m.error);
    });
    child.on('exit', (code) => {
      if (this.jobs.get(b) !== child) return;
      this.jobs.delete(b);
      this.progress.delete(b);
      if (!this.installed(id)) {
        this.errors.set(b, FAILED);
        this.lastReason = reason || ('kod ' + code);
      }
    });
  }

  /** Removes a downloaded voice to free the space. */
  remove(id) {
    if (!known(id)) return;
    const b = base(id);
    const job = this.jobs.get(b);
    if (job) { this.jobs.delete(b); this.progress.delete(b); try { job.kill(); } catch (e) { /* already gone */ } }
    this.errors.delete(b);
    rmrf(this.dir(id));
    rmrf(this.dir(id) + '.part');
  }
}

module.exports = { VOICES, VoiceStore, base, pitchOf, known };
