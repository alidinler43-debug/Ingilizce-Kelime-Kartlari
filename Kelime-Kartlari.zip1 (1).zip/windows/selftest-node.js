// Build-time check (run by ci-build.sh with plain Node, before the installer is made):
// downloads two voices exactly as the app does (a release voice and İlkız) and makes each speak.
// If anything fails the build stops, so a broken voice engine never reaches the PC.
'use strict';
const path = require('path');
const fs = require('fs');
const { fork } = require('child_process');

const APP = process.argv[2];   // the prepared app folder (with node_modules)
const ROOT = process.argv[3];  // where the test voices go
const IDS = (process.argv[4] || 'en_US-amy-medium,tr_TR-ilkiz-medium').split(',');

const { VoiceStore } = require(path.join(APP, 'voices.js'));
const { createEngine, synth } = require(path.join(APP, 'tts-engine.js'));

function writeWav(file, samples, rate) {
  const n = samples.length;
  const b = Buffer.alloc(44 + n * 2);
  b.write('RIFF', 0); b.writeUInt32LE(36 + n * 2, 4); b.write('WAVE', 8); b.write('fmt ', 12);
  b.writeUInt32LE(16, 16); b.writeUInt16LE(1, 20); b.writeUInt16LE(1, 22); b.writeUInt32LE(rate, 24);
  b.writeUInt32LE(rate * 2, 28); b.writeUInt16LE(2, 32); b.writeUInt16LE(16, 34); b.write('data', 36); b.writeUInt32LE(n * 2, 40);
  for (let i = 0; i < n; i++) b.writeInt16LE(Math.max(-32768, Math.min(32767, Math.round(samples[i] * 32767))), 44 + i * 2);
  fs.writeFileSync(file, b);
}

async function main() {
  fs.mkdirSync(ROOT, { recursive: true });
  const store = new VoiceStore(ROOT, function (file, env) {
    return fork(file, [], { env: Object.assign({}, process.env, env), cwd: APP });
  });
  for (const id of IDS) {
    if (store.installed(id)) { console.log(id + ': zaten var'); continue; }
    const t0 = Date.now();
    store.download(id);
    let last = -2;
    await new Promise(function (resolve, reject) {
      const tick = setInterval(function () {
        const v = store.list().filter(function (x) { return x.id === id; })[0];
        if (v.progress !== last && v.progress % 10 === 0) { last = v.progress; console.log(id + ': %' + v.progress); }
        if (v.installed) { clearInterval(tick); resolve(); }
        else if (v.error) { clearInterval(tick); reject(new Error(id + ': ' + v.error + ' (' + store.lastReason + ')')); }
      }, 250);
    });
    console.log(id + ': indirildi, ' + Math.round((Date.now() - t0) / 1000) + ' sn');
  }
  const sherpa = require(path.join(APP, 'node_modules', 'sherpa-onnx-node'));
  const sample = { en: 'Hello! Nice to meet you. This is a test of the voice.', tr: 'Merhaba! Bugün birlikte yeni kelimeler öğreniyoruz.' };
  const all = IDS.concat(IDS.indexOf('tr_TR-ilkiz-medium') >= 0 ? ['tr_TR-ilkiz-warm'] : []);
  for (const id of all) {
    const tts = createEngine(sherpa, store.dir(id), store.espeakDir());
    const pitch = store.pitchOf(id);
    const a = synth(tts, sample[id.slice(0, 2)], 1 / pitch);
    const secs = a.samples.length / a.sampleRate;
    let peak = 0;
    for (let i = 0; i < a.samples.length; i++) peak = Math.max(peak, Math.abs(a.samples[i]));
    console.log(id + ': ' + secs.toFixed(2) + ' sn ses, ' + a.sampleRate + ' Hz, tepe ' + peak.toFixed(2));
    if (!(secs > 1 && peak > 0.05)) throw new Error(id + ': ses üretilemedi');
    writeWav(path.join(ROOT, 'deneme-' + id + '.wav'), a.samples, Math.round(a.sampleRate * pitch));
  }
  console.log('Sesler tamam.');
}

main().catch(function (e) { console.error('HATA: ' + ((e && e.stack) || e)); process.exit(1); });
