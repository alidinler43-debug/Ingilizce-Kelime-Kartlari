// Kelime Kartları: keeps the app working offline and picks up new versions when online.
var APP_CACHE = 'kelime-kartlari-app-v1';
var FONT_CACHE = 'kelime-kartlari-fonts';
var APP_FILES = ['./', './index.html', './manifest.webmanifest', './icons/icon-192.png', './icons/icon-512.png', './icons/icon-maskable-512.png'];

self.addEventListener('install', function(e){
  e.waitUntil(caches.open(APP_CACHE).then(function(c){ return c.addAll(APP_FILES); }).then(function(){ return self.skipWaiting(); }));
});

self.addEventListener('activate', function(e){
  e.waitUntil(caches.keys().then(function(keys){
    return Promise.all(keys.filter(function(k){ return k !== APP_CACHE && k !== FONT_CACHE; }).map(function(k){ return caches.delete(k); }));
  }).then(function(){ return self.clients.claim(); }));
});

self.addEventListener('fetch', function(e){
  var req = e.request;
  if (req.method !== 'GET') return;
  var url = new URL(req.url);

  // Fonts: use the saved copy, refresh it in the background.
  if (url.hostname === 'fonts.googleapis.com' || url.hostname === 'fonts.gstatic.com') {
    e.respondWith(caches.open(FONT_CACHE).then(function(cache){
      return cache.match(req).then(function(hit){
        var net = fetch(req).then(function(res){ if (res.ok || res.type === 'opaque') cache.put(req, res.clone()); return res; }).catch(function(){ return hit; });
        return hit || net;
      });
    }));
    return;
  }
  if (url.origin !== self.location.origin) return;

  // The app page: try the newest version first, fall back to the saved one when offline.
  if (req.mode === 'navigate') {
    e.respondWith(fetch(req).then(function(res){
      var copy = res.clone();
      caches.open(APP_CACHE).then(function(c){ c.put('./index.html', copy); });
      return res;
    }).catch(function(){ return caches.match('./index.html'); }));
    return;
  }

  // Icons and other files.
  e.respondWith(caches.match(req).then(function(hit){
    return hit || fetch(req).then(function(res){
      var copy = res.clone();
      caches.open(APP_CACHE).then(function(c){ c.put(req, copy); });
      return res;
    });
  }));
});
