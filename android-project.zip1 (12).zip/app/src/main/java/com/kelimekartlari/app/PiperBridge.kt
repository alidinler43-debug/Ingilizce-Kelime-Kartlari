package com.kelimekartlari.app

import com.k2fsa.sherpa.onnx.OfflineTts
import com.k2fsa.sherpa.onnx.OfflineTtsConfig
import com.k2fsa.sherpa.onnx.OfflineTtsModelConfig
import com.k2fsa.sherpa.onnx.OfflineTtsVitsModelConfig

/**
 * A thin bridge between the app's Java code and sherpa-onnx's Kotlin text-to-speech API.
 * Named arguments keep it working even when sherpa-onnx adds new settings with defaults.
 */
object PiperBridge {
    @JvmStatic
    fun create(model: String, tokens: String, dataDir: String): OfflineTts {
        val config = OfflineTtsConfig(
            model = OfflineTtsModelConfig(
                vits = OfflineTtsVitsModelConfig(model = model, tokens = tokens, dataDir = dataDir),
                numThreads = 2,
                debug = false,
                provider = "cpu",
            ),
        )
        return OfflineTts(assetManager = null, config = config)
    }

    @JvmStatic
    fun generate(tts: OfflineTts, text: String, speed: Float): FloatArray =
        tts.generate(text = text, sid = 0, speed = speed).samples

    @JvmStatic
    fun sampleRate(tts: OfflineTts): Int = tts.sampleRate()
}
