package com.kelimekartlari.app;

import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.nio.charset.StandardCharsets;
import java.util.Calendar;

/**
 * Word notifications: every one, two or three hours a notification shows the next word
 * ("habit — alışkanlık"). Quiet between 22:00 and 08:00. Re-armed after the tablet restarts.
 */
public class WordNotify extends BroadcastReceiver {

    private static final String CHANNEL = "words";
    static final String ACTION_SHOW = "com.kelimekartlari.app.WORD_SHOW";
    private static final int NOTE_ID = 4201;

    /** Saves the settings and word list ({hours, words:[[en, tr, example]]}) and (re)arms the alarm. */
    static void set(Context ctx, String json) throws Exception {
        JSONObject o = new JSONObject(json);
        int hours = o.optInt("hours", 0);
        File f = new File(ctx.getFilesDir(), "notify_words.json");
        try (FileOutputStream out = new FileOutputStream(f)) {
            out.write(o.optJSONArray("words") == null ? "[]".getBytes(StandardCharsets.UTF_8) : o.getJSONArray("words").toString().getBytes(StandardCharsets.UTF_8));
        }
        prefs(ctx).edit().putInt("hours", hours).putInt("next", 0).apply();
        arm(ctx);
    }

    private static SharedPreferences prefs(Context ctx) {
        return ctx.getSharedPreferences("word_notify", Context.MODE_PRIVATE);
    }

    private static PendingIntent pending(Context ctx) {
        int imm = Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0;
        Intent i = new Intent(ctx, WordNotify.class).setAction(ACTION_SHOW);
        return PendingIntent.getBroadcast(ctx, 0, i, imm | PendingIntent.FLAG_UPDATE_CURRENT);
    }

    static void arm(Context ctx) {
        AlarmManager am = (AlarmManager) ctx.getSystemService(Context.ALARM_SERVICE);
        if (am == null) return;
        PendingIntent pi = pending(ctx);
        am.cancel(pi);
        int hours = prefs(ctx).getInt("hours", 0);
        if (hours <= 0) return;
        long every = hours * AlarmManager.INTERVAL_HOUR;
        // inexact repeating alarms need no special permission and are kind to the battery
        am.setInexactRepeating(AlarmManager.RTC, System.currentTimeMillis() + every, every, pi);
    }

    @Override
    public void onReceive(Context ctx, Intent intent) {
        String a = intent == null ? null : intent.getAction();
        if (Intent.ACTION_BOOT_COMPLETED.equals(a) || "android.intent.action.MY_PACKAGE_REPLACED".equals(a)) {
            arm(ctx);
            return;
        }
        if (!ACTION_SHOW.equals(a)) return;
        int h = Calendar.getInstance().get(Calendar.HOUR_OF_DAY);
        if (h >= 22 || h < 8) return;
        try {
            File f = new File(ctx.getFilesDir(), "notify_words.json");
            if (!f.exists()) return;
            byte[] b = new byte[(int) f.length()];
            try (FileInputStream in = new FileInputStream(f)) {
                int off = 0;
                while (off < b.length) { int n = in.read(b, off, b.length - off); if (n < 0) break; off += n; }
            }
            JSONArray words = new JSONArray(new String(b, StandardCharsets.UTF_8));
            if (words.length() == 0) return;
            SharedPreferences p = prefs(ctx);
            int i = p.getInt("next", 0) % words.length();
            p.edit().putInt("next", i + 1).apply();
            JSONArray w = words.getJSONArray(i);
            show(ctx, w.optString(0, ""), w.optString(1, ""), w.optString(2, ""));
        } catch (Exception ignored) {
        }
    }

    private static void show(Context ctx, String en, String tr, String example) {
        NotificationManager nm = (NotificationManager) ctx.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null) return;
        if (Build.VERSION.SDK_INT >= 26 && nm.getNotificationChannel(CHANNEL) == null) {
            NotificationChannel ch = new NotificationChannel(CHANNEL, "Kelime bildirimi", NotificationManager.IMPORTANCE_DEFAULT);
            ch.setDescription("Gün içinde aralıklarla bir kelime");
            ch.setSound(null, null);
            nm.createNotificationChannel(ch);
        }
        int imm = Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0;
        PendingIntent open = PendingIntent.getActivity(ctx, 0,
                new Intent(ctx, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP), imm | PendingIntent.FLAG_UPDATE_CURRENT);
        Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(ctx, CHANNEL) : new Notification.Builder(ctx);
        b.setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle(en + " — " + tr)
                .setContentText(example.length() > 0 ? example : "Kelime Kartları")
                .setStyle(new Notification.BigTextStyle().bigText(example.length() > 0 ? example : "Kelime Kartları"))
                .setContentIntent(open)
                .setAutoCancel(true);
        nm.notify(NOTE_ID, b.build());
    }
}
