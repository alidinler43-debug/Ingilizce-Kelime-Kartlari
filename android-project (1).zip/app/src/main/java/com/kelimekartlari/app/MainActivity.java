package com.kelimekartlari.app;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.view.WindowManager;
import android.speech.tts.Voice;
import android.webkit.JavascriptInterface;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.Locale;
import java.util.Set;

/** Shows the flashcards, which are packed inside the app, full screen. */
public class MainActivity extends Activity {

    private static final String GOOGLE_TTS = "com.google.android.tts";

    private WebView web;
    private TextToSpeech tts;
    private volatile boolean ttsReady = false;
    private volatile String wantedVoice = "";
    private volatile String wantedTrVoice = "";
    private volatile float wantedRate = 0.9f;
    private volatile String enginePkg = null;
    private AppVoices appVoices;

    /** The app voices' speed, from the same setting as the phone voice (0.9 is the app's normal). */
    private float appSpeed() {
        return Math.max(0.5f, Math.min(2.0f, wantedRate / 0.9f));
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // The engine chosen in the app's settings is used; otherwise Google's engine (widest choice of English voices) when the phone has it.
        startTts(initialEngine());
        appVoices = new AppVoices(this);

        web = new WebView(this);
        WebSettings settings = web.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        // The page is packed inside the app (file://), so it needs this to reach the account service.
        allowAccountRequests(settings);
        settings.setTextZoom(100);
        web.addJavascriptInterface(new Speech(), "AndroidTTS");
        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                if ("file".equals(uri.getScheme())) return false;
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, uri));
                } catch (Exception ignored) {
                }
                return true;
            }
        });

        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
    }

    @SuppressWarnings("deprecation")
    private static void allowAccountRequests(WebSettings settings) {
        settings.setAllowUniversalAccessFromFileURLs(true);
    }

    @SuppressWarnings("deprecation")
    /** Starts (or restarts) the speech engine; null means the phone's default engine. */
    private void startTts(String pkg) {
        ttsReady = false;
        if (tts != null) {
            try { tts.stop(); tts.shutdown(); } catch (Exception ignored) { }
            tts = null;
        }
        enginePkg = pkg;
        tts = new TextToSpeech(this, status -> {
            if (status == TextToSpeech.SUCCESS && tts != null) {
                ttsReady = true;
                applyVoice();
                // tells the page when a sentence has been read, so the listening mode can go on to the next one
                tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
                    @Override public void onStart(String id) { }
                    @Override public void onDone(String id) { notifyDone(id); }
                    @Override public void onError(String id) { notifyDone(id); }
                });
            }
        }, pkg);
    }

    /** The engine the person picked in the app (if it is still installed), otherwise Google's, otherwise the default. */
    private String initialEngine() {
        String saved = getSharedPreferences("speech", MODE_PRIVATE).getString("engine", "");
        if (saved != null && saved.length() > 0) {
            try {
                getPackageManager().getPackageInfo(saved, 0);
                return saved;
            } catch (Exception ignored) { }
        }
        return googleEngineIfInstalled();
    }

    private String googleEngineIfInstalled() {
        try {
            getPackageManager().getPackageInfo(GOOGLE_TTS, 0);
            return GOOGLE_TTS;
        } catch (Exception e) {
            return null;
        }
    }

    /** Uses the voice and speed chosen in the app's settings, or the default American English voice. */
    private void applyVoice() {
        TextToSpeech t = tts;
        if (t == null || !ttsReady) return;
        boolean voiceSet = false;
        String name = wantedVoice;
        if (name != null && !name.isEmpty()) {
            try {
                Set<Voice> voices = t.getVoices();
                if (voices != null) {
                    for (Voice v : voices) {
                        if (name.equals(v.getName())) {
                            voiceSet = t.setVoice(v) == TextToSpeech.SUCCESS;
                            break;
                        }
                    }
                }
            } catch (Exception ignored) {
            }
        }
        if (!voiceSet) t.setLanguage(Locale.US);
        t.setSpeechRate(wantedRate);
    }

    private volatile boolean turkishActive = false;

    /** The Turkish voice chosen in the app (a voice of the phone's engine), otherwise the engine's Turkish. */
    private void applyTurkish(TextToSpeech t) {
        boolean ok = false;
        String name = wantedTrVoice;
        if (name != null && name.length() > 0 && !AppVoices.isAppVoice(name)) {
            try {
                Set<Voice> voices = t.getVoices();
                if (voices != null) for (Voice v : voices) if (name.equals(v.getName())) { ok = t.setVoice(v) == TextToSpeech.SUCCESS; break; }
            } catch (Exception ignored) { }
        }
        if (!ok) t.setLanguage(new Locale("tr", "TR"));
        t.setSpeechRate(wantedRate);
    }

    private void notifyDone(String id) {
        WebView w = web;
        if (w == null || id == null) return;
        w.post(() -> w.evaluateJavascript("window.__ttsDone && window.__ttsDone(" + JSONObject.quote(id) + ")", null));
    }

    /** Pronunciation through the phone's text-to-speech engine. */
    public class Speech {
        @JavascriptInterface
        public void speak(String text) {
            if (AppVoices.isAppVoice(wantedVoice)) {
                if (tts != null) tts.stop();
                appVoices.speak(wantedVoice, text, appSpeed(), null, null);
                return;
            }
            appVoices.stop();
            if (tts == null) return;
            if (turkishActive) { turkishActive = false; applyVoice(); }
            tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "kelime");
        }

        /** Reads a text in English ("en") or Turkish ("tr"); the page is told with the id when it ends. */
        @JavascriptInterface
        public void speakLang(String text, String lang, String id) {
            boolean turkish = lang != null && lang.startsWith("tr");
            String appVoice = turkish ? wantedTrVoice : wantedVoice;
            if (AppVoices.isAppVoice(appVoice) && (!turkish || appVoices.has(appVoice))) {
                if (tts != null) tts.stop();
                appVoices.speak(appVoice, text, appSpeed(), id, MainActivity.this::notifyDone);
                return;
            }
            appVoices.stop();
            TextToSpeech t = tts;
            if (t == null) return;
            if (turkish) {
                applyTurkish(t);
                turkishActive = true;
            } else if (turkishActive) {
                turkishActive = false;
                applyVoice();
            }
            t.speak(text, TextToSpeech.QUEUE_FLUSH, null, id);
        }

        /** Whether the phone has a voice for this language ("tr", "en"). */
        @JavascriptInterface
        public boolean hasLang(String lang) {
            TextToSpeech t = tts;
            if (t == null || !ttsReady) return false;
            try {
                return t.isLanguageAvailable(new Locale(lang)) >= TextToSpeech.LANG_AVAILABLE;
            } catch (Exception e) {
                return false;
            }
        }

        /** Keeps the screen on while the listening mode is playing. */
        @JavascriptInterface
        public void keepAwake(boolean on) {
            runOnUiThread(() -> {
                if (on) getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
                else getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
            });
        }

        @JavascriptInterface
        public void stop() {
            appVoices.stop();
            if (tts != null) tts.stop();
        }

        /** Background listening / sleep mode: starts the service with a play list (JSON). */
        @JavascriptInterface
        public void bgStart(String json) {
            appVoices.stop();
            if (tts != null) tts.stop();
            try { ListenService.start(MainActivity.this, json); } catch (Exception ignored) { }
        }

        @JavascriptInterface
        public void bgStop() {
            ListenService.stop(MainActivity.this);
        }

        /** {playing, index, total, en, sleep, left} */
        @JavascriptInterface
        public String bgState() {
            return ListenService.state();
        }

        /** Word notifications: {hours (0 = off), words:[[en, tr, example]]}. */
        @JavascriptInterface
        public void notifySet(String json) {
            try { WordNotify.set(MainActivity.this, json); } catch (Exception ignored) { }
        }

        /** Asks once for permission to show notifications (Android 13 and newer). */
        @JavascriptInterface
        public void askNotify() {
            if (android.os.Build.VERSION.SDK_INT < 33) return;
            runOnUiThread(() -> {
                try {
                    if (checkSelfPermission("android.permission.POST_NOTIFICATIONS") != android.content.pm.PackageManager.PERMISSION_GRANTED) {
                        requestPermissions(new String[] { "android.permission.POST_NOTIFICATIONS" }, 7);
                    }
                } catch (Exception ignored) { }
            });
        }

        /** The app's own voices: [{id, label, gender, accent, installed, progress, error}]. */
        @JavascriptInterface
        public String appVoices() {
            return appVoices.list();
        }

        /** Downloads one app voice (once), from the official sherpa-onnx release. */
        @JavascriptInterface
        public void appVoiceDownload(String id) {
            appVoices.download(id);
        }

        /** Deletes a downloaded app voice to free the space. */
        @JavascriptInterface
        public void appVoiceDelete(String id) {
            appVoices.delete(id);
        }

        /** The Turkish voices of the phone's engine, as JSON: [{name, locale, network, missing}]. */
        @JavascriptInterface
        public String voicesTr() {
            return voicesOf("tr");
        }

        /** The Turkish voice to use: a phone voice name, "app:<id>" for the app's own, or "" for the default. */
        @JavascriptInterface
        public void setTrVoice(String name) {
            wantedTrVoice = name == null ? "" : name;
            if (tts != null && turkishActive) applyTurkish(tts);
        }

        /** The English voices installed on the phone, as JSON: [{name, locale, network}]. */
        @JavascriptInterface
        public String voices() {
            return voicesOf("en");
        }

        private String voicesOf(String language) {
            JSONArray out = new JSONArray();
            TextToSpeech t = tts;
            if (t == null || !ttsReady) return out.toString();
            try {
                Set<Voice> voices = t.getVoices();
                if (voices != null) {
                    for (Voice v : voices) {
                        Locale locale = v.getLocale();
                        if (locale == null || !language.equals(locale.getLanguage())) continue;
                        Set<String> features = v.getFeatures();
                        boolean missing = features != null && features.contains(TextToSpeech.Engine.KEY_FEATURE_NOT_INSTALLED);
                        JSONObject o = new JSONObject();
                        o.put("missing", missing);
                        o.put("name", v.getName());
                        o.put("locale", locale.toLanguageTag());
                        o.put("network", v.isNetworkConnectionRequired());
                        out.put(o);
                    }
                }
            } catch (Exception ignored) {
            }
            return out.toString();
        }

        @JavascriptInterface
        public void setVoice(String name) {
            wantedVoice = name == null ? "" : name;
            applyVoice();
        }

        @JavascriptInterface
        public void setRate(double rate) {
            wantedRate = (float) rate;
            applyVoice();
        }

        /** Sets the voice pitch (1.0 is normal), so the two people in a video lesson sound different. */
        @JavascriptInterface
        public void setPitch(double pitch) {
            if (tts != null) tts.setPitch((float) pitch);
        }

        /** The speech engines installed on the phone: [{name, label, current, def}]. */
        @JavascriptInterface
        public String engines() {
            JSONArray out = new JSONArray();
            TextToSpeech t = tts;
            if (t == null) return out.toString();
            try {
                String def = t.getDefaultEngine();
                String cur = enginePkg != null ? enginePkg : def;
                for (TextToSpeech.EngineInfo e : t.getEngines()) {
                    JSONObject o = new JSONObject();
                    o.put("name", e.name);
                    o.put("label", e.label);
                    o.put("current", e.name.equals(cur));
                    o.put("def", e.name.equals(def));
                    out.put(o);
                }
            } catch (Exception ignored) { }
            return out.toString();
        }

        /** Switches to another installed engine and remembers it for the next start. */
        @JavascriptInterface
        public void setEngine(String name) {
            final String pkg = (name == null || name.length() == 0) ? null : name;
            getSharedPreferences("speech", MODE_PRIVATE).edit().putString("engine", pkg == null ? "" : pkg).apply();
            runOnUiThread(() -> startTts(pkg));
        }

        /** True once the engine has started and its voices can be listed. */
        @JavascriptInterface
        public boolean ready() {
            return ttsReady;
        }

        /** Opens the phone's text-to-speech settings, where more voices can be downloaded. */
        @JavascriptInterface
        public void openSettings() {
            try {
                Intent i = new Intent("com.android.settings.TTS_SETTINGS");
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(i);
            } catch (Exception ignored) {
            }
        }
    }

    @Override
    @SuppressWarnings("deprecation")
    public void onBackPressed() {
        // The page goes back from a card or list to the home screen; on the home screen the app closes.
        web.evaluateJavascript("(window.appBack && window.appBack()) ? 'y' : 'n'", value -> {
            if (!"\"y\"".equals(value)) finish();
        });
    }

    @Override
    protected void onDestroy() {
        if (appVoices != null) appVoices.stop();
        if (tts != null) {
            tts.stop();
            tts.shutdown();
            tts = null;
        }
        if (web != null) web.destroy();
        super.onDestroy();
    }
}
