package com.kelimekartlari.app;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.speech.tts.Voice;
import android.webkit.JavascriptInterface;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.Locale;
import java.util.Set;

/** Shows the flashcards, which are packed inside the app, full screen. */
public class MainActivity extends Activity {

    private static final String GOOGLE_TTS = "com.google.android.tts";

    private WebView web;
    private TextToSpeech tts;
    private volatile boolean ttsReady = false;
    private volatile String wantedVoice = "";
    private volatile float wantedRate = 0.9f;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Google's voice engine has the widest choice of English voices, so it is used when the phone has it.
        tts = new TextToSpeech(this, status -> {
            if (status == TextToSpeech.SUCCESS && tts != null) {
                ttsReady = true;
                applyVoice();
            }
        }, googleEngineIfInstalled());

        web = new WebView(this);
        WebSettings settings = web.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        // The page is packed inside the app (file://), so it needs this to reach the account service.
        allowAccountRequests(settings);
        settings.setTextZoom(100);
        web.addJavascriptInterface(new Speech(), "AndroidTTS");
        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                if ("file".equals(uri.getScheme())) return false;
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, uri));
                } catch (Exception ignored) {
                }
                return true;
            }
        });

        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
    }

    @SuppressWarnings("deprecation")
    private static void allowAccountRequests(WebSettings settings) {
        settings.setAllowUniversalAccessFromFileURLs(true);
    }

    @SuppressWarnings("deprecation")
    private String googleEngineIfInstalled() {
        try {
            getPackageManager().getPackageInfo(GOOGLE_TTS, 0);
            return GOOGLE_TTS;
        } catch (Exception e) {
            return null;
        }
    }

    /** Uses the voice and speed chosen in the app's settings, or the default American English voice. */
    private void applyVoice() {
        TextToSpeech t = tts;
        if (t == null || !ttsReady) return;
        boolean voiceSet = false;
        String name = wantedVoice;
        if (name != null && !name.isEmpty()) {
            try {
                Set<Voice> voices = t.getVoices();
                if (voices != null) {
                    for (Voice v : voices) {
                        if (name.equals(v.getName())) {
                            voiceSet = t.setVoice(v) == TextToSpeech.SUCCESS;
                            break;
                        }
                    }
                }
            } catch (Exception ignored) {
            }
        }
        if (!voiceSet) t.setLanguage(Locale.US);
        t.setSpeechRate(wantedRate);
    }

    /** Pronunciation through the phone's text-to-speech engine. */
    public class Speech {
        @JavascriptInterface
        public void speak(String text) {
            if (tts != null) tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "kelime");
        }

        @JavascriptInterface
        public void stop() {
            if (tts != null) tts.stop();
        }

        /** The English voices installed on the phone, as JSON: [{name, locale, network}]. */
        @JavascriptInterface
        public String voices() {
            JSONArray out = new JSONArray();
            TextToSpeech t = tts;
            if (t == null || !ttsReady) return out.toString();
            try {
                Set<Voice> voices = t.getVoices();
                if (voices != null) {
                    for (Voice v : voices) {
                        Locale locale = v.getLocale();
                        if (locale == null || !"en".equals(locale.getLanguage())) continue;
                        Set<String> features = v.getFeatures();
                        if (features != null && features.contains(TextToSpeech.Engine.KEY_FEATURE_NOT_INSTALLED)) continue;
                        JSONObject o = new JSONObject();
                        o.put("name", v.getName());
                        o.put("locale", locale.toLanguageTag());
                        o.put("network", v.isNetworkConnectionRequired());
                        out.put(o);
                    }
                }
            } catch (Exception ignored) {
            }
            return out.toString();
        }

        @JavascriptInterface
        public void setVoice(String name) {
            wantedVoice = name == null ? "" : name;
            applyVoice();
        }

        @JavascriptInterface
        public void setRate(double rate) {
            wantedRate = (float) rate;
            applyVoice();
        }

        /** Sets the voice pitch (1.0 is normal), so the two people in a video lesson sound different. */
        @JavascriptInterface
        public void setPitch(double pitch) {
            if (tts != null) tts.setPitch((float) pitch);
        }

        /** Opens the phone's text-to-speech settings, where more voices can be downloaded. */
        @JavascriptInterface
        public void openSettings() {
            try {
                Intent i = new Intent("com.android.settings.TTS_SETTINGS");
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(i);
            } catch (Exception ignored) {
            }
        }
    }

    @Override
    @SuppressWarnings("deprecation")
    public void onBackPressed() {
        // The page goes back from a card or list to the home screen; on the home screen the app closes.
        web.evaluateJavascript("(window.appBack && window.appBack()) ? 'y' : 'n'", value -> {
            if (!"\"y\"".equals(value)) finish();
        });
    }

    @Override
    protected void onDestroy() {
        if (tts != null) {
            tts.stop();
            tts.shutdown();
            tts = null;
        }
        if (web != null) web.destroy();
        super.onDestroy();
    }
}
