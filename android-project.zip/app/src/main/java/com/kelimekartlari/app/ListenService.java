package com.kelimekartlari.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.speech.tts.Voice;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.nio.charset.StandardCharsets;
import java.util.Locale;
import java.util.Set;

/**
 * Background listening and sleep mode: for each card it reads its parts in order
 * (English word → Turkish → English sentence → Turkish), while the screen is off or another app is open.
 * English and Turkish each have their own speech engine instance, so switching languages never
 * swallows a word. Runs as a media foreground service with a notification that has a stop button;
 * a sleep timer and a slow fade-out can end it on its own.
 */
public class ListenService extends Service {

    static final String ACTION_START = "com.kelimekartlari.app.LISTEN_START";
    static final String ACTION_STOP = "com.kelimekartlari.app.LISTEN_STOP";
    private static final String CHANNEL = "listen";
    private static final int NOTE_ID = 4101;

    // read by the page through the bridge
    static volatile boolean playing = false;
    static volatile int index = 0;
    static volatile int seg = 0;
    static volatile int total = 0;
    static volatile String nowEn = "";
    static volatile String nowItem = "null";
    static volatile long endAt = 0;
    static volatile boolean sleepMode = false;

    private final Handler main = new Handler(Looper.getMainLooper());
    private TextToSpeech ttsEn, ttsTr;
    private boolean readyEn = false, readyTr = false;
    private int initsLeft = 0;
    private AppVoices appVoices;
    private PowerManager.WakeLock wake;

    /** One entry per card: its display JSON, and the parts to read as {text, "en"|"tr"}. */
    private String[] itemJson = new String[0];
    private String[][][] segs = new String[0][][];
    private String[] titles = new String[0], subtitles = new String[0];
    private String voiceName = "";
    private float rate = 0.9f, volume = 1f;
    private long gapMs = 1000, betweenMs = 1800;
    private boolean fade = false;
    private long startAt = 0;
    private int token = 0;

    /** Writes the play list and starts the service. */
    static void start(Context ctx, String json) throws Exception {
        File f = new File(ctx.getFilesDir(), "listen.json");
        try (FileOutputStream o = new FileOutputStream(f)) { o.write(json.getBytes(StandardCharsets.UTF_8)); }
        Intent i = new Intent(ctx, ListenService.class).setAction(ACTION_START);
        if (Build.VERSION.SDK_INT >= 26) ctx.startForegroundService(i); else ctx.startService(i);
    }

    static void stop(Context ctx) {
        ctx.startService(new Intent(ctx, ListenService.class).setAction(ACTION_STOP));
    }

    static String state() {
        try {
            JSONObject o = new JSONObject();
            o.put("playing", playing);
            o.put("index", index);
            o.put("seg", seg);
            o.put("total", total);
            o.put("en", nowEn);
            o.put("sleep", sleepMode);
            o.put("left", endAt > 0 ? Math.max(0, endAt - System.currentTimeMillis()) : 0);
            String it = nowItem;
            if (playing && it != null && !"null".equals(it)) o.put("item", new JSONObject(it));
            return o.toString();
        } catch (Exception e) {
            return "null";
        }
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent == null ? null : intent.getAction();
        if (ACTION_STOP.equals(action) || action == null) {
            // a foreground start must always be followed by startForeground, even when stopping at once
            goForeground("Durduruluyor…");
            finish();
            return START_NOT_STICKY;
        }
        if (!load()) {
            goForeground("Liste boş");
            finish();
            return START_NOT_STICKY;
        }
        goForeground(sleepMode ? "🌙 Uyku modu" : "🎧 Arka planda dinleme");
        if (wake == null) {
            PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
            wake = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "KelimeKartlari:listen");
            wake.setReferenceCounted(false);
        }
        long limit = endAt > 0 ? endAt - System.currentTimeMillis() + 60000 : 3 * 3600000L;
        wake.acquire(Math.max(60000, limit));
        if (appVoices == null) appVoices = new AppVoices(this);
        if (appVoices != null) appVoices.stop();
        token++;
        playing = true;
        index = 0;
        seg = 0;
        final int my = token;
        if (ttsEn == null && ttsTr == null) {
            initsLeft = 2;
            String eng = engine();
            // the engine may report readiness right inside the constructor on some phones, so it is handled one step later
            ttsEn = new TextToSpeech(this, status -> main.post(() -> {
                if (ttsEn == null) return;
                readyEn = status == TextToSpeech.SUCCESS;
                if (readyEn) { listen(ttsEn); applyEnglish(); }
                initDone(my);
            }), eng);
            ttsTr = new TextToSpeech(this, status -> main.post(() -> {
                if (ttsTr == null) return;
                readyTr = status == TextToSpeech.SUCCESS;
                if (readyTr) { listen(ttsTr); try { ttsTr.setLanguage(new Locale("tr", "TR")); } catch (Exception ignored) { } }
                initDone(my);
            }), eng);
        } else {
            if (ttsEn != null) try { ttsEn.stop(); } catch (Exception ignored) { }
            if (ttsTr != null) try { ttsTr.stop(); } catch (Exception ignored) { }
            applyEnglish();
            main.post(() -> next(my));
        }
        return START_NOT_STICKY;
    }

    private void initDone(int my) {
        if (--initsLeft == 0) next(my);
    }

    private void listen(TextToSpeech t) {
        t.setOnUtteranceProgressListener(new UtteranceProgressListener() {
            @Override public void onStart(String id) { }
            @Override public void onDone(String id) { utteranceDone(id, false); }
            @Override public void onError(String id) { utteranceDone(id, true); }
            @Override public void onError(String id, int code) { utteranceDone(id, true); }
        });
    }

    /** The English engine: the voice chosen in the app if the phone has it, otherwise American English. */
    private void applyEnglish() {
        TextToSpeech t = ttsEn;
        if (t == null || !readyEn) return;
        boolean ok = false;
        if (voiceName != null && voiceName.length() > 0 && !AppVoices.isAppVoice(voiceName)) {
            try {
                Set<Voice> vs = t.getVoices();
                if (vs != null) for (Voice v : vs) if (voiceName.equals(v.getName())) { ok = t.setVoice(v) == TextToSpeech.SUCCESS; break; }
            } catch (Exception ignored) { }
        }
        if (!ok) try { t.setLanguage(Locale.US); } catch (Exception ignored) { }
    }

    private boolean load() {
        try {
            File f = new File(getFilesDir(), "listen.json");
            byte[] b = new byte[(int) f.length()];
            try (FileInputStream in = new FileInputStream(f)) {
                int off = 0;
                while (off < b.length) { int n = in.read(b, off, b.length - off); if (n < 0) break; off += n; }
            }
            JSONObject o = new JSONObject(new String(b, StandardCharsets.UTF_8));
            JSONArray a = o.getJSONArray("items");
            int n = a.length();
            itemJson = new String[n];
            segs = new String[n][][];
            titles = new String[n];
            subtitles = new String[n];
            for (int i = 0; i < n; i++) {
                JSONObject it = a.getJSONObject(i);
                itemJson[i] = it.toString();
                JSONArray sg = it.optJSONArray("segs");
                if (sg != null && sg.length() > 0) {
                    segs[i] = new String[sg.length()][];
                    for (int k = 0; k < sg.length(); k++) {
                        JSONArray p = sg.getJSONArray(k);
                        segs[i][k] = new String[] { p.optString(0, ""), p.optString(1, "en") };
                    }
                    titles[i] = it.optString("w", segs[i][0][0]);
                    subtitles[i] = it.optString("wt", segs[i].length > 1 ? segs[i][1][0] : "");
                } else {
                    // older list format: {en, tr}
                    String en = it.optString("en", ""), tr = it.optString("tr", "");
                    segs[i] = new String[][] { { en, "en" }, { tr, "tr" } };
                    titles[i] = en;
                    subtitles[i] = tr;
                }
            }
            voiceName = o.optString("voice", "");
            rate = (float) o.optDouble("rate", 0.9);
            volume = (float) o.optDouble("volume", 1.0);
            gapMs = (long) (o.optDouble("gap", 1.0) * 1000);
            betweenMs = (long) (o.optDouble("between", 1.8) * 1000);
            fade = o.optBoolean("fade", false);
            sleepMode = o.optBoolean("sleep", false);
            int minutes = o.optInt("minutes", 0);
            startAt = System.currentTimeMillis();
            endAt = minutes > 0 ? startAt + minutes * 60000L : 0;
            total = n;
            return n > 0;
        } catch (Exception e) {
            return false;
        }
    }

    /** The engine chosen in the app (if still installed), otherwise Google's, otherwise the default. */
    private String engine() {
        String saved = getSharedPreferences("speech", MODE_PRIVATE).getString("engine", "");
        for (String pkg : new String[] { saved, "com.google.android.tts" }) {
            if (pkg == null || pkg.length() == 0) continue;
            try { getPackageManager().getPackageInfo(pkg, 0); return pkg; } catch (Exception ignored) { }
        }
        return null;
    }

    /** The volume now: in the last 60 % of a timed run with fade on, it goes down to a whisper. */
    private float currentVolume() {
        if (!fade || endAt <= 0) return volume;
        float p = (System.currentTimeMillis() - startAt) / (float) Math.max(1, endAt - startAt);
        if (p < 0.4f) return volume;
        float k = 1f - Math.min(1f, (p - 0.4f) / 0.6f) * 0.8f;
        return Math.max(0.05f, volume * k);
    }

    // ---- the reading loop: part after part of one card, a short gap between parts, a longer one between cards
    private Runnable pending = null;
    private String pendingId = null;
    private String pendingText = null;
    private boolean pendingTurkish = false, pendingRetried = false;

    private void next(int my) {
        if (my != token || !playing) return;
        if (endAt > 0 && System.currentTimeMillis() >= endAt) { finish(); return; }
        int i = index % segs.length;
        nowEn = titles[i];
        nowItem = itemJson[i];
        updateNote(titles[i], subtitles[i]);
        part(my, 0);
    }

    private void part(int my, int k) {
        if (my != token || !playing) return;
        final String[][] list = segs[index % segs.length];
        if (k >= list.length) {
            wait(betweenMs, () -> {
                if (my != token) return;
                index = (index + 1) % segs.length;
                seg = 0;
                next(my);
            });
            return;
        }
        seg = k;
        say(list[k][0], "tr".equals(list[k][1]), () -> {
            if (k + 1 < list.length) wait(gapMs, () -> part(my, k + 1));
            else part(my, k + 1);
        });
    }

    private void wait(long ms, Runnable then) {
        final int my = token;
        main.postDelayed(() -> { if (my == token && playing) then.run(); }, ms);
    }

    private int seq = 0;

    private void say(String text, boolean turkish, Runnable then) {
        final int my = token;
        if (text == null || text.trim().length() == 0) { then.run(); return; }
        final String id = "bg" + (++seq);
        Runnable guarded = () -> { if (my == token && playing && id.equals(pendingId)) { pendingId = null; pending = null; then.run(); } };
        pendingId = id;
        pending = guarded;
        pendingText = text;
        pendingTurkish = turkish;
        pendingRetried = false;
        // a safety limit in case the engine never says it has finished
        main.postDelayed(guarded, 7000 + text.length() * 170L);
        float vol = currentVolume();
        if (!turkish && AppVoices.isAppVoice(voiceName) && appVoices != null) {
            appVoices.setVolume(vol);
            appVoices.speak(voiceName, text, Math.max(0.5f, Math.min(2f, rate / 0.9f)), id, done -> main.post(() -> {
                // the app voice could not speak (not downloaded / failed): read it with the phone's English voice instead
                if (appVoices.lastFailed && id.equals(pendingId)) speakSystem(text, false, id, vol);
                else utteranceDone(done, false);
            }));
            return;
        }
        speakSystem(text, turkish, id, vol);
    }

    private void speakSystem(String text, boolean turkish, String id, float vol) {
        TextToSpeech t = turkish ? ttsTr : ttsEn;
        boolean ready = turkish ? readyTr : readyEn;
        if (t == null || !ready) { utteranceDone(id, false); return; }
        try {
            t.setSpeechRate(rate);
            Bundle p = new Bundle();
            p.putFloat(TextToSpeech.Engine.KEY_PARAM_VOLUME, vol);
            if (t.speak(text, TextToSpeech.QUEUE_FLUSH, p, id) != TextToSpeech.SUCCESS) utteranceDone(id, true);
        } catch (Exception e) {
            utteranceDone(id, true);
        }
    }

    private void utteranceDone(String id, boolean error) {
        main.post(() -> {
            if (id == null || !id.equals(pendingId)) return;
            if (error && !pendingTurkish && !pendingRetried && ttsEn != null && readyEn) {
                // the chosen English voice failed (e.g. a network voice offline): try once more with plain American English
                pendingRetried = true;
                try { ttsEn.setLanguage(Locale.US); } catch (Exception ignored) { }
                voiceName = "";
                speakSystem(pendingText, false, id, currentVolume());
                return;
            }
            Runnable r = pending;
            if (r != null) r.run();
        });
    }

    // ---- notification
    private Notification build(String title, String text) {
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= 26 && nm.getNotificationChannel(CHANNEL) == null) {
            NotificationChannel ch = new NotificationChannel(CHANNEL, "Arka planda dinleme", NotificationManager.IMPORTANCE_LOW);
            ch.setDescription("Dinleme ve uyku modu çalarken görünür");
            nm.createNotificationChannel(ch);
        }
        int imm = Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0;
        PendingIntent open = PendingIntent.getActivity(this, 0,
                new Intent(this, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP), imm | PendingIntent.FLAG_UPDATE_CURRENT);
        PendingIntent stop = PendingIntent.getService(this, 1,
                new Intent(this, ListenService.class).setAction(ACTION_STOP), imm | PendingIntent.FLAG_UPDATE_CURRENT);
        Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(this, CHANNEL) : new Notification.Builder(this);
        b.setSmallIcon(android.R.drawable.ic_media_play)
                .setContentTitle(title)
                .setContentText(text)
                .setContentIntent(open)
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .addAction(android.R.drawable.ic_media_pause, "Durdur", stop);
        return b.build();
    }

    private void goForeground(String title) {
        Notification n = build(title, "Kelime Kartları");
        if (Build.VERSION.SDK_INT >= 29) startForeground(NOTE_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK);
        else startForeground(NOTE_ID, n);
    }

    private void updateNote(String en, String tr) {
        try {
            String title = (sleepMode ? "🌙 " : "🎧 ") + en;
            String left = endAt > 0 ? " · " + Math.max(1, (endAt - System.currentTimeMillis() + 59999) / 60000) + " dk kaldı" : "";
            ((NotificationManager) getSystemService(NOTIFICATION_SERVICE)).notify(NOTE_ID, build(title, tr + left));
        } catch (Exception ignored) { }
    }

    private void finish() {
        token++;
        playing = false;
        sleepMode = false;
        endAt = 0;
        nowEn = "";
        nowItem = "null";
        pending = null;
        pendingId = null;
        main.removeCallbacksAndMessages(null);
        if (appVoices != null) appVoices.stop();
        if (ttsEn != null) try { ttsEn.stop(); } catch (Exception ignored) { }
        if (ttsTr != null) try { ttsTr.stop(); } catch (Exception ignored) { }
        if (wake != null && wake.isHeld()) try { wake.release(); } catch (Exception ignored) { }
        if (Build.VERSION.SDK_INT >= 24) stopForeground(STOP_FOREGROUND_REMOVE); else stopForeground(true);
        stopSelf();
    }

    @Override
    public void onDestroy() {
        playing = false;
        token++;
        main.removeCallbacksAndMessages(null);
        if (appVoices != null) appVoices.stop();
        for (TextToSpeech t : new TextToSpeech[] { ttsEn, ttsTr }) {
            if (t != null) try { t.stop(); t.shutdown(); } catch (Exception ignored) { }
        }
        ttsEn = null;
        ttsTr = null;
        if (wake != null && wake.isHeld()) try { wake.release(); } catch (Exception ignored) { }
        super.onDestroy();
    }
}
