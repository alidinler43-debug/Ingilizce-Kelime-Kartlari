package com.kelimekartlari.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.speech.tts.Voice;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.nio.charset.StandardCharsets;
import java.util.Locale;
import java.util.Set;

/**
 * Background listening and sleep mode: reads English → Turkish → English again, item after item,
 * while the screen is off or another app is open. Runs as a media foreground service with a
 * notification that has a stop button; a sleep timer and a slow fade-out can end it on its own.
 */
public class ListenService extends Service {

    static final String ACTION_START = "com.kelimekartlari.app.LISTEN_START";
    static final String ACTION_STOP = "com.kelimekartlari.app.LISTEN_STOP";
    private static final String CHANNEL = "listen";
    private static final int NOTE_ID = 4101;

    // read by the page through the bridge
    static volatile boolean playing = false;
    static volatile int index = 0;
    static volatile int total = 0;
    static volatile String nowEn = "";
    static volatile long endAt = 0;
    static volatile boolean sleepMode = false;

    private final Handler main = new Handler(Looper.getMainLooper());
    private TextToSpeech tts;
    private boolean ttsReady = false;
    private AppVoices appVoices;
    private PowerManager.WakeLock wake;

    private String[][] items = new String[0][];
    private String voiceName = "";
    private float rate = 0.9f, volume = 1f;
    private long gapMs = 1200, betweenMs = 2000;
    private boolean repeat = true, fade = false;
    private long startAt = 0;
    private int token = 0;
    private Voice englishVoice = null;

    /** Writes the play list and starts the service. */
    static void start(Context ctx, String json) throws Exception {
        File f = new File(ctx.getFilesDir(), "listen.json");
        try (FileOutputStream o = new FileOutputStream(f)) { o.write(json.getBytes(StandardCharsets.UTF_8)); }
        Intent i = new Intent(ctx, ListenService.class).setAction(ACTION_START);
        if (Build.VERSION.SDK_INT >= 26) ctx.startForegroundService(i); else ctx.startService(i);
    }

    static void stop(Context ctx) {
        ctx.startService(new Intent(ctx, ListenService.class).setAction(ACTION_STOP));
    }

    static String state() {
        try {
            JSONObject o = new JSONObject();
            o.put("playing", playing);
            o.put("index", index);
            o.put("total", total);
            o.put("en", nowEn);
            o.put("sleep", sleepMode);
            o.put("left", endAt > 0 ? Math.max(0, endAt - System.currentTimeMillis()) : 0);
            return o.toString();
        } catch (Exception e) {
            return "null";
        }
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent == null ? null : intent.getAction();
        if (ACTION_STOP.equals(action) || action == null) {
            // a foreground start must always be followed by startForeground, even when stopping at once
            goForeground("Durduruluyor…");
            finish();
            return START_NOT_STICKY;
        }
        if (!load()) {
            goForeground("Liste boş");
            finish();
            return START_NOT_STICKY;
        }
        goForeground(sleepMode ? "🌙 Uyku modu" : "🎧 Arka planda dinleme");
        if (wake == null) {
            PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
            wake = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "KelimeKartlari:listen");
            wake.setReferenceCounted(false);
        }
        long limit = endAt > 0 ? endAt - System.currentTimeMillis() + 60000 : 3 * 3600000L;
        wake.acquire(Math.max(60000, limit));
        if (appVoices == null) appVoices = new AppVoices(this);
        token++;
        playing = true;
        index = 0;
        if (tts == null) {
            // the engine may report readiness right inside the constructor on some phones, so it is handled one step later
            tts = new TextToSpeech(this, status -> main.post(() -> {
                if (tts == null) return;
                ttsReady = status == TextToSpeech.SUCCESS;
                if (ttsReady) {
                    tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
                        @Override public void onStart(String id) { }
                        @Override public void onDone(String id) { utteranceDone(id); }
                        @Override public void onError(String id) { utteranceDone(id); }
                    });
                    englishVoice = findVoice(voiceName);
                }
                next(token);
            }), engine());
        } else {
            englishVoice = findVoice(voiceName);
            main.post(() -> next(token));
        }
        return START_NOT_STICKY;
    }

    private boolean load() {
        try {
            File f = new File(getFilesDir(), "listen.json");
            byte[] b = new byte[(int) f.length()];
            try (FileInputStream in = new FileInputStream(f)) {
                int off = 0;
                while (off < b.length) { int n = in.read(b, off, b.length - off); if (n < 0) break; off += n; }
            }
            JSONObject o = new JSONObject(new String(b, StandardCharsets.UTF_8));
            JSONArray a = o.getJSONArray("items");
            items = new String[a.length()][];
            for (int i = 0; i < a.length(); i++) {
                JSONObject it = a.getJSONObject(i);
                items[i] = new String[] { it.optString("en", ""), it.optString("tr", "") };
            }
            voiceName = o.optString("voice", "");
            rate = (float) o.optDouble("rate", 0.9);
            volume = (float) o.optDouble("volume", 1.0);
            gapMs = (long) (o.optDouble("gap", 1.2) * 1000);
            betweenMs = (long) (o.optDouble("between", 2) * 1000);
            repeat = o.optBoolean("repeat", true);
            fade = o.optBoolean("fade", false);
            sleepMode = o.optBoolean("sleep", false);
            int minutes = o.optInt("minutes", 0);
            startAt = System.currentTimeMillis();
            endAt = minutes > 0 ? startAt + minutes * 60000L : 0;
            total = items.length;
            return items.length > 0;
        } catch (Exception e) {
            return false;
        }
    }

    /** The engine chosen in the app (if still installed), otherwise Google's, otherwise the default. */
    private String engine() {
        String saved = getSharedPreferences("speech", MODE_PRIVATE).getString("engine", "");
        for (String pkg : new String[] { saved, "com.google.android.tts" }) {
            if (pkg == null || pkg.length() == 0) continue;
            try { getPackageManager().getPackageInfo(pkg, 0); return pkg; } catch (Exception ignored) { }
        }
        return null;
    }

    private Voice findVoice(String name) {
        if (tts == null || name == null || name.length() == 0 || AppVoices.isAppVoice(name)) return null;
        try {
            Set<Voice> vs = tts.getVoices();
            if (vs != null) for (Voice v : vs) if (name.equals(v.getName())) return v;
        } catch (Exception ignored) { }
        return null;
    }

    /** The volume now: in the last 60 % of a timed run with fade on, it goes down to a whisper. */
    private float currentVolume() {
        if (!fade || endAt <= 0) return volume;
        float p = (System.currentTimeMillis() - startAt) / (float) Math.max(1, endAt - startAt);
        if (p < 0.4f) return volume;
        float k = 1f - Math.min(1f, (p - 0.4f) / 0.6f) * 0.8f;
        return Math.max(0.05f, volume * k);
    }

    // ---- the reading loop: en → gap → tr → gap → en (again) → pause → next item
    private Runnable pending = null;
    private String pendingId = null;

    private void next(int my) {
        if (my != token || !playing) return;
        if (endAt > 0 && System.currentTimeMillis() >= endAt) { finish(); return; }
        final String[] it = items[index % items.length];
        nowEn = it[0];
        updateNote(it[0], it[1]);
        say(it[0], false, () -> wait(gapMs, () -> say(it[1], true, () -> wait(gapMs, () -> {
            Runnable after = () -> wait(betweenMs, () -> {
                if (my != token) return;
                index = (index + 1) % items.length;
                next(my);
            });
            if (repeat) say(it[0], false, after); else after.run();
        }))));
    }

    private void wait(long ms, Runnable then) {
        final int my = token;
        main.postDelayed(() -> { if (my == token && playing) then.run(); }, ms);
    }

    private int seq = 0;

    private void say(String text, boolean turkish, Runnable then) {
        final int my = token;
        if (text == null || text.trim().length() == 0) { then.run(); return; }
        final String id = "bg" + (++seq);
        Runnable guarded = () -> { if (my == token && playing && id.equals(pendingId)) { pendingId = null; pending = null; then.run(); } };
        pendingId = id;
        pending = guarded;
        // a safety limit in case the engine never says it has finished
        main.postDelayed(guarded, 6000 + text.length() * 160L);
        float vol = currentVolume();
        if (!turkish && AppVoices.isAppVoice(voiceName)) {
            appVoices.setVolume(vol);
            appVoices.speak(voiceName, text, Math.max(0.5f, Math.min(2f, rate / 0.9f)), id, done -> main.post(() -> utteranceDone(done)));
            return;
        }
        if (tts == null || !ttsReady) { main.postDelayed(guarded, 800); return; }
        try {
            if (turkish) tts.setLanguage(new Locale("tr", "TR"));
            else if (englishVoice != null) tts.setVoice(englishVoice);
            else tts.setLanguage(Locale.US);
            tts.setSpeechRate(rate);
            Bundle p = new Bundle();
            p.putFloat(TextToSpeech.Engine.KEY_PARAM_VOLUME, vol);
            tts.speak(text, TextToSpeech.QUEUE_FLUSH, p, id);
        } catch (Exception e) {
            main.postDelayed(guarded, 500);
        }
    }

    private void utteranceDone(String id) {
        main.post(() -> { Runnable r = pending; if (r != null && id != null && id.equals(pendingId)) r.run(); });
    }

    // ---- notification
    private Notification build(String title, String text) {
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= 26 && nm.getNotificationChannel(CHANNEL) == null) {
            NotificationChannel ch = new NotificationChannel(CHANNEL, "Arka planda dinleme", NotificationManager.IMPORTANCE_LOW);
            ch.setDescription("Dinleme ve uyku modu çalarken görünür");
            nm.createNotificationChannel(ch);
        }
        int imm = Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0;
        PendingIntent open = PendingIntent.getActivity(this, 0,
                new Intent(this, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP), imm | PendingIntent.FLAG_UPDATE_CURRENT);
        PendingIntent stop = PendingIntent.getService(this, 1,
                new Intent(this, ListenService.class).setAction(ACTION_STOP), imm | PendingIntent.FLAG_UPDATE_CURRENT);
        Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(this, CHANNEL) : new Notification.Builder(this);
        b.setSmallIcon(android.R.drawable.ic_media_play)
                .setContentTitle(title)
                .setContentText(text)
                .setContentIntent(open)
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .addAction(android.R.drawable.ic_media_pause, "Durdur", stop);
        return b.build();
    }

    private void goForeground(String title) {
        Notification n = build(title, "Kelime Kartları");
        if (Build.VERSION.SDK_INT >= 29) startForeground(NOTE_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK);
        else startForeground(NOTE_ID, n);
    }

    private void updateNote(String en, String tr) {
        try {
            String title = (sleepMode ? "🌙 " : "🎧 ") + en;
            String left = endAt > 0 ? " · " + Math.max(1, (endAt - System.currentTimeMillis() + 59999) / 60000) + " dk kaldı" : "";
            ((NotificationManager) getSystemService(NOTIFICATION_SERVICE)).notify(NOTE_ID, build(title, tr + left));
        } catch (Exception ignored) { }
    }

    private void finish() {
        token++;
        playing = false;
        sleepMode = false;
        endAt = 0;
        nowEn = "";
        pending = null;
        pendingId = null;
        main.removeCallbacksAndMessages(null);
        if (appVoices != null) appVoices.stop();
        if (tts != null) try { tts.stop(); } catch (Exception ignored) { }
        if (wake != null && wake.isHeld()) try { wake.release(); } catch (Exception ignored) { }
        if (Build.VERSION.SDK_INT >= 24) stopForeground(STOP_FOREGROUND_REMOVE); else stopForeground(true);
        stopSelf();
    }

    @Override
    public void onDestroy() {
        playing = false;
        token++;
        main.removeCallbacksAndMessages(null);
        if (appVoices != null) appVoices.stop();
        if (tts != null) { try { tts.stop(); tts.shutdown(); } catch (Exception ignored) { } tts = null; }
        if (wake != null && wake.isHeld()) try { wake.release(); } catch (Exception ignored) { }
        super.onDestroy();
    }
}
